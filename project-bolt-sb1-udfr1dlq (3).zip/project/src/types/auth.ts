export interface User {
  id: number;
  email: string;
  password?: string;
  created_at: Date;
  updated_at: Date;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  confirmPassword: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token?: string;
  user?: Omit<User, 'password'>;
}

export interface ChatFeedback {
  id: number;
  user_id: number;
  session_id: string;
  message_id: string;
  response_content: string;
  feedback_type: 'like' | 'dislike' | null;
  created_at: Date;
}