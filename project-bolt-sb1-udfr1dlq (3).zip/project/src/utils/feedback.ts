import { getConnection } from './database';
import { ChatFeedback } from '../types/auth';

export const saveChatFeedback = async (
  userId: number,
  sessionId: string,
  messageId: string,
  responseContent: string,
  feedbackType: 'like' | 'dislike' | null = null
): Promise<boolean> => {
  try {
    const connection = await getConnection();

    // Check if feedback already exists for this message
    const existingFeedback = await connection.request()
      .input('userId', userId)
      .input('messageId', messageId)
      .query('SELECT id FROM chat_feedback WHERE user_id = @userId AND message_id = @messageId');

    if (existingFeedback.recordset.length > 0) {
      // Update existing feedback
      await connection.request()
        .input('userId', userId)
        .input('messageId', messageId)
        .input('feedbackType', feedbackType)
        .query(`
          UPDATE chat_feedback 
          SET feedback_type = @feedbackType 
          WHERE user_id = @userId AND message_id = @messageId
        `);
    } else {
      // Insert new feedback record
      await connection.request()
        .input('userId', userId)
        .input('sessionId', sessionId)
        .input('messageId', messageId)
        .input('responseContent', responseContent)
        .input('feedbackType', feedbackType)
        .query(`
          INSERT INTO chat_feedback (user_id, session_id, message_id, response_content, feedback_type)
          VALUES (@userId, @sessionId, @messageId, @responseContent, @feedbackType)
        `);
    }

    return true;
  } catch (error) {
    console.error('Error saving chat feedback:', error);
    return false;
  }
};

export const getFeedbackStats = async (userId?: number) => {
  try {
    const connection = await getConnection();
    
    let query = `
      SELECT 
        feedback_type,
        COUNT(*) as count
      FROM chat_feedback 
    `;
    
    const request = connection.request();
    
    if (userId) {
      query += ' WHERE user_id = @userId';
      request.input('userId', userId);
    }
    
    query += ' GROUP BY feedback_type';
    
    const result = await request.query(query);
    
    const stats = {
      likes: 0,
      dislikes: 0,
      no_feedback: 0
    };
    
    result.recordset.forEach(row => {
      if (row.feedback_type === 'like') {
        stats.likes = row.count;
      } else if (row.feedback_type === 'dislike') {
        stats.dislikes = row.count;
      } else if (row.feedback_type === null) {
        stats.no_feedback = row.count;
      }
    });
    
    return stats;
  } catch (error) {
    console.error('Error getting feedback stats:', error);
    return { likes: 0, dislikes: 0, no_feedback: 0 };
  }
};

export const getFeedbackHistory = async (userId: number): Promise<ChatFeedback[]> => {
  try {
    const connection = await getConnection();
    
    const result = await connection.request()
      .input('userId', userId)
      .query(`
        SELECT id, user_id, session_id, message_id, response_content, feedback_type, created_at
        FROM chat_feedback 
        WHERE user_id = @userId 
        ORDER BY created_at DESC
      `);
    
    return result.recordset;
  } catch (error) {
    console.error('Error getting feedback history:', error);
    return [];
  }
};