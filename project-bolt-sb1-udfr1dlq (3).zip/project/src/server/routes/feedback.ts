import express from 'express';
import { saveChatFeedback, getFeedbackStats, getFeedbackHistory } from '../utils/feedback';
import { verifyToken } from '../utils/auth';

const router = express.Router();

// Middleware to verify authentication
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }

  const tokenData = verifyToken(token);
  if (!tokenData) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }

  req.user = tokenData;
  next();
};

// Save feedback endpoint
router.post('/save', authenticateToken, async (req: any, res: any) => {
  try {
    const { sessionId, messageId, responseContent, feedbackType } = req.body;
    const userId = req.user.userId;

    const success = await saveChatFeedback(userId, sessionId, messageId, responseContent, feedbackType);
    
    if (success) {
      res.status(200).json({ success: true, message: 'Feedback saved successfully' });
    } else {
      res.status(500).json({ success: false, message: 'Failed to save feedback' });
    }
  } catch (error) {
    console.error('Save feedback route error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Get feedback stats endpoint
router.get('/stats', authenticateToken, async (req: any, res: any) => {
  try {
    const userId = req.user.userId;
    const stats = await getFeedbackStats(userId);
    
    res.status(200).json({ success: true, data: stats });
  } catch (error) {
    console.error('Get feedback stats route error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Get feedback history endpoint
router.get('/history', authenticateToken, async (req: any, res: any) => {
  try {
    const userId = req.user.userId;
    const history = await getFeedbackHistory(userId);
    
    res.status(200).json({ success: true, data: history });
  } catch (error) {
    console.error('Get feedback history route error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

export default router;