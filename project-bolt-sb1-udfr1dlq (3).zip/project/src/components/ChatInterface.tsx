import React, { useState, useEffect, useRef } from 'react';
import { Send, Shield, Lock, User, Bot, Terminal, AlertTriangle, Eye, Zap, ThumbsUp, ThumbsDown, LogOut } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  feedback?: 'like' | 'dislike' | null;
}

interface Session {
  id: string;
  openingMessage: string;
}

interface User {
  id: number;
  email: string;
  created_at: Date;
  updated_at: Date;
}

interface ChatInterfaceProps {
  user: User;
  token: string;
  onLogout: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ user, token, onLogout }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  // Initialize session on component mount
  useEffect(() => {
    initializeSession();
  }, []);

  const initializeSession = async () => {
    try {
      setIsInitializing(true);
      // Replace with your actual API endpoint
      const response = await fetch('/api/start-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const sessionData = await response.json();
        setSession(sessionData);
        
        // Add opening message
        const openingMessage: Message = {
          id: 'opening-' + Date.now(),
          content: sessionData.openingMessage || "🛡️ CyberGuard AI initialized. I'm your cybersecurity assistant. How can I help secure your digital environment today?",
          role: 'assistant',
          timestamp: new Date(),
        };
        
        setMessages([openingMessage]);
      } else {
        // Fallback for demo
        const fallbackSession = {
          id: 'demo-session-' + Date.now(),
          openingMessage: "🛡️ CyberGuard AI initialized. I'm your cybersecurity assistant. How can I help secure your digital environment today?"
        };
        setSession(fallbackSession);
        
        const openingMessage: Message = {
          id: 'opening-' + Date.now(),
          content: fallbackSession.openingMessage,
          role: 'assistant',
          timestamp: new Date(),
        };
        
        setMessages([openingMessage]);
      }
    } catch (error) {
      console.error('Failed to initialize session:', error);
      // Fallback for demo
      const fallbackSession = {
        id: 'demo-session-' + Date.now(),
        openingMessage: "🛡️ CyberGuard AI initialized. I'm your cybersecurity assistant. How can I help secure your digital environment today?"
      };
      setSession(fallbackSession);
      
      const openingMessage: Message = {
        id: 'opening-' + Date.now(),
        content: fallbackSession.openingMessage,
        role: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages([openingMessage]);
    } finally {
      setIsInitializing(false);
    }
  };

  const sendMessage = async () => {
    if (!inputValue.trim() || isLoading || !session) return;

    const userMessage: Message = {
      id: 'user-' + Date.now(),
      content: inputValue.trim(),
      role: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setIsThinking(true);

    try {
      // Replace with your actual chat endpoint
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage.content,
          session_id: session.id,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        const assistantMessage: Message = {
          id: 'assistant-' + Date.now(),
          content: data.response || "I've analyzed your security concern. Let me provide you with a comprehensive solution to strengthen your defenses.",
          role: 'assistant',
          timestamp: new Date(),
          feedback: null,
        };

        // Save to database without feedback initially
        try {
          await fetch('/api/feedback/save', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
              user_id: user.id,
              session_id: session.id,
              message_id: assistantMessage.id,
              response_content: assistantMessage.content,
              feedback: null,
            }),
          });
        } catch (error) {
          console.error('Failed to save feedback:', error);
        }

        // Simulate thinking delay
        setTimeout(() => {
          setIsThinking(false);
          setMessages(prev => [...prev, assistantMessage]);
        }, 1500);
      } else {
        // Fallback response for demo
        const fallbackResponse = "I've identified potential security vulnerabilities in your query. Based on current threat intelligence, I recommend implementing multi-layered security protocols. Would you like me to detail specific countermeasures?";
        
        const assistantMessage: Message = {
          id: 'assistant-' + Date.now(),
          content: fallbackResponse,
          role: 'assistant',
          timestamp: new Date(),
          feedback: null,
        };

        // Save to database without feedback initially
        try {
          await fetch('/api/feedback/save', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
              user_id: user.id,
              session_id: session.id,
              message_id: assistantMessage.id,
              response_content: assistantMessage.content,
              feedback: null,
            }),
          });
        } catch (error) {
          console.error('Failed to save feedback:', error);
        }

        setTimeout(() => {
          setIsThinking(false);
          setMessages(prev => [...prev, assistantMessage]);
        }, 1500);
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      setIsThinking(false);
      
      const errorMessage: Message = {
        id: 'error-' + Date.now(),
        content: "⚠️ Connection to security database temporarily unavailable. Retrying secure channel... Please standby.",
        role: 'assistant',
        timestamp: new Date(),
        feedback: null,
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedback = async (messageId: string, feedbackType: 'like' | 'dislike') => {
    const message = messages.find(m => m.id === messageId);
    if (!message || !session) return;

    // Update UI immediately
    setMessages(prev => prev.map(m => 
      m.id === messageId 
        ? { ...m, feedback: m.feedback === feedbackType ? null : feedbackType }
        : m
    ));

    // Save to database
    const newFeedback = message.feedback === feedbackType ? null : feedbackType;
    try {
      await fetch('/api/feedback/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          user_id: user.id,
          session_id: session.id,
          message_id: messageId,
          response_content: message.content,
          feedback: newFeedback,
        }),
      });
    } catch (error) {
      console.error('Failed to save feedback:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const ThinkingAnimation = () => (
    <div className="flex items-center space-x-2 p-4 bg-gray-900/90 border border-cyan-500/30 rounded-2xl shadow-lg max-w-xs backdrop-blur-sm">
      <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full animate-pulse">
        <Bot className="w-4 h-4 text-white" />
      </div>
      <div className="flex space-x-1">
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
      </div>
      <span className="text-xs text-cyan-300 font-mono">Analyzing...</span>
    </div>
  );

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-cyan-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-cyan-300 font-mono">Initializing CyberGuard AI...</p>
          <p className="text-gray-400 text-sm mt-2">Establishing secure connection...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black flex overflow-hidden">
      {/* Sidebar */}
      <div className="hidden lg:flex lg:w-64 bg-gradient-to-b from-black via-gray-900 to-gray-800 border-r border-cyan-500/20 p-6 flex-col">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/25">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-semibold text-white tracking-tight">CyberGuard AI</h1>
        </div>
        
        <div className="flex-1">
          <div className="bg-gray-800/50 border border-cyan-500/20 rounded-xl p-4 mb-4">
            <div className="flex items-center space-x-2 mb-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-semibold text-cyan-300 tracking-wide">Active Session</h2>
            </div>
            <p className="text-xs text-gray-400 font-mono break-all leading-relaxed">{session?.id}</p>
            <div className="flex items-center space-x-1 mt-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-400 font-medium">Secure</span>
            </div>
          </div>
          
          <div className="bg-gray-800/50 border border-cyan-500/20 rounded-xl p-4 mb-4">
            <div className="flex items-center space-x-2 mb-2">
              <Eye className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-semibold text-cyan-300 tracking-wide">Security Tips</h2>
            </div>
            <ul className="text-xs text-gray-400 space-y-1 leading-relaxed">
              <li>• Describe specific threats or vulnerabilities</li>
              <li>• Mention your current security setup</li>
              <li>• Ask about best practices and protocols</li>
            </ul>
          </div>

          <div className="bg-gray-800/50 border border-red-500/20 rounded-xl p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <h2 className="text-sm font-semibold text-red-300 tracking-wide">Threat Level</h2>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex-1 bg-gray-700 rounded-full h-2">
                <div className="bg-gradient-to-r from-green-500 to-yellow-500 h-2 rounded-full w-3/5"></div>
              </div>
              <span className="text-xs text-yellow-400 font-mono font-medium">MODERATE</span>
            </div>
          </div>
        </div>

        <div className="mt-auto">
          <div className="bg-gray-800/30 border border-cyan-500/10 rounded-xl p-3">
            <div className="flex items-center space-x-2 text-xs text-gray-400 font-medium">
              <Lock className="w-3 h-3" />
              <span>End-to-end encrypted</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-gray-900/90 backdrop-blur-sm border-b border-cyan-500/20 p-4 lg:p-6">
          <div className="flex items-center space-x-3">
            <div className="lg:hidden w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-cyan-500/25">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg lg:text-xl font-semibold text-white tracking-tight">CyberGuard AI Assistant</h1>
              <p className="text-sm text-cyan-300 font-medium">Your advanced cybersecurity companion</p>
              <p className="text-xs text-gray-400 mt-1">Welcome, {user.email}</p>
            </div>
            <div className="ml-auto flex items-center space-x-2">
              <button
                onClick={onLogout}
                className="flex items-center space-x-1 px-3 py-1.5 bg-gray-800/50 border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:border-gray-500 transition-all duration-200"
              >
                <LogOut className="w-3 h-3" />
                <span className="text-xs font-medium">Logout</span>
              </button>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-400 font-mono font-medium">ONLINE</span>
              </div>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 bg-gradient-to-b from-gray-900/50 to-gray-800/50 pb-24">
          {messages.map((message, index) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`flex max-w-xs sm:max-w-md lg:max-w-2xl ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'} space-x-3`}>
                <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  message.role === 'user' 
                    ? 'bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg shadow-emerald-500/25' 
                    : 'bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/25'
                }`}>
                  {message.role === 'user' ? 
                    <User className="w-4 h-4 text-white" /> : 
                    <Bot className="w-4 h-4 text-white" />
                  }
                </div>
                
                <div className={`px-4 py-3 rounded-2xl shadow-sm ${
                  message.role === 'user'
                    ? 'bg-gradient-to-br from-emerald-500 to-green-600 text-white rounded-br-md shadow-lg shadow-emerald-500/25'
                    : 'bg-gray-900/90 border border-cyan-500/30 text-gray-100 rounded-bl-md shadow-lg backdrop-blur-sm'
                }`}>
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                  <div className="flex items-center justify-between mt-2">
                    <p className={`text-xs ${
                      message.role === 'user' ? 'text-green-100' : 'text-cyan-400'
                    } font-medium`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    
                    {message.role === 'assistant' && (
                      <div className="flex items-center space-x-1 ml-4">
                        <button
                          onClick={() => handleFeedback(message.id, 'like')}
                          className={`p-1 rounded transition-all duration-200 ${
                            message.feedback === 'like'
                              ? 'bg-green-500/20 text-green-400'
                              : 'text-gray-400 hover:text-green-400 hover:bg-green-500/10'
                          }`}
                        >
                          <ThumbsUp className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleFeedback(message.id, 'dislike')}
                          className={`p-1 rounded transition-all duration-200 ${
                            message.feedback === 'dislike'
                              ? 'bg-red-500/20 text-red-400'
                              : 'text-gray-400 hover:text-red-400 hover:bg-red-500/10'
                          }`}
                        >
                          <ThumbsDown className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {isThinking && (
            <div className="flex justify-start animate-fadeIn">
              <ThinkingAnimation />
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="fixed bottom-0 right-0 left-0 lg:left-64 bg-gray-900/95 backdrop-blur-md border-t border-cyan-500/20 p-4 lg:p-6">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-end space-x-4">
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={isLoading}
                  placeholder={isLoading ? "CyberGuard AI is analyzing..." : "Describe your security concerns or ask for threat analysis..."}
                  className="w-full px-4 py-3 pr-12 bg-gray-800/70 border border-cyan-500/30 text-white placeholder-gray-400 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 resize-none shadow-lg disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-sm text-sm leading-relaxed"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <Zap className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              
              <button
                onClick={sendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 text-white rounded-xl hover:from-cyan-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center shadow-lg shadow-cyan-500/25"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            
            <p className="text-xs text-gray-400 mt-3 text-center font-medium">
              Press Enter to send • CyberGuard AI provides threat analysis, security protocols, and defense strategies
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;