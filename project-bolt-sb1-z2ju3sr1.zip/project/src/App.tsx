import React from 'react';
import ADMETViewer from './components/ADMETViewer';

function App() {
  return (
    <div className="App">
      <ADMETViewer />
    </div>
  );
}

export default App;