import React, { useState } from 'react';
import { 
  Pill, 
  Activity, 
  Target, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Info,
  TrendingUp,
  Clock,
  Zap,
  Database,
  BarChart3,
  Beaker,
  Shield
} from 'lucide-react';

interface DetailedADMETData {
  smiles: { "0": string };
  filepath: { "0": string };
  molecular_weight: { "0": number };
  logP: { "0": number };
  hydrogen_bond_acceptors: { "0": number };
  hydrogen_bond_donors: { "0": number };
  Lipinski: { "0": number };
  QED: { "0": number };
  stereo_centers: { "0": number };
  tpsa: { "0": number };
  AMES: { "0": number };
  BBB_Martins: { "0": number };
  Bioavailability_Ma: { "0": number };
  CYP1A2_Veith: { "0": number };
  CYP2C19_Veith: { "0": number };
  CYP2C9_Substrate_CarbonMangels: { "0": number };
  CYP2C9_Veith: { "0": number };
  CYP2D6_Substrate_CarbonMangels: { "0": number };
  CYP2D6_Veith: { "0": number };
  CYP3A4_Substrate_CarbonMangels: { "0": number };
  CYP3A4_Veith: { "0": number };
  Carcinogens_Lagunin: { "0": number };
  ClinTox: { "0": number };
  DILI: { "0": number };
  HIA_Hou: { "0": number };
  hERG: { "0": number };
  Caco2_Wang: { "0": number };
  Clearance_Hepatocyte_AZ: { "0": number };
  Half_Life_Obach: { "0": number };
  LD50_Zhu: { "0": number };
  Solubility_AqSolDB: { "0": number };
  VDss_Lombardo: { "0": number };
  Skin_Reaction: { "0": number };
  PPBR_AZ: { "0": number };
  PAMPA_NCATS: { "0": number };
  Pgp_Broccatelli: { "0": number };
}

interface SummarizedADMETData {
  smiles: { "0": string };
  filepath: { "0": string };
  Absorption: { "0": number };
  Distribution: { "0": number };
  Metabolism: { "0": number };
  Excretion: { "0": number };
  Toxicity: { "0": number };
}

interface APIResponse {
  ligand: string;
  detailed_admet_details: DetailedADMETData;
  summarized_admet_details: SummarizedADMETData;
}

// Sample data matching your API structure
const sampleAPIResponse: APIResponse = {
  "ligand": "CHEMBL6640_output_9_rank01_confidence_-0.47",
  "detailed_admet_details": {
    "smiles": { "0": "NCC[C@@H]1CC[C@H]2CCC[C@H]2N1" },
    "filepath": { "0": "/home/CyberSecurity/drug_discovery_poc_v2/data/nvidia_diffdock_outputs/1U72/output/CHEMBL6640_output_9_rank01_confidence_-0.47.sdf" },
    "molecular_weight": { "0": 168.28400000000002 },
    "logP": { "0": 1.2559 },
    "hydrogen_bond_acceptors": { "0": 2 },
    "hydrogen_bond_donors": { "0": 2 },
    "Lipinski": { "0": 4 },
    "QED": { "0": 0.6511136791912974 },
    "stereo_centers": { "0": 3 },
    "tpsa": { "0": 38.05 },
    "AMES": { "0": 0.11769381724298 },
    "BBB_Martins": { "0": 0.8824813485145568 },
    "Bioavailability_Ma": { "0": 0.9200278043746948 },
    "CYP1A2_Veith": { "0": 0.0060248112305998 },
    "CYP2C19_Veith": { "0": 0.0089324404019862 },
    "CYP2C9_Substrate_CarbonMangels": { "0": 0.0429084299132227 },
    "CYP2C9_Veith": { "0": 0.0008699457219336 },
    "CYP2D6_Substrate_CarbonMangels": { "0": 0.7417466402053833 },
    "CYP2D6_Veith": { "0": 0.1328518331050872 },
    "CYP3A4_Substrate_CarbonMangels": { "0": 0.0750420235097408 },
    "CYP3A4_Veith": { "0": 0.006819348008139 },
    "Carcinogens_Lagunin": { "0": 0.0107572337496094 },
    "ClinTox": { "0": 0.0395118624903261 },
    "DILI": { "0": 0.0216230331454426 },
    "HIA_Hou": { "0": 0.9996704220771788 },
    "hERG": { "0": 0.2564791545271873 },
    "Caco2_Wang": { "0": -4.955258241967864 },
    "Clearance_Hepatocyte_AZ": { "0": 14.882031794943885 },
    "Half_Life_Obach": { "0": -14.42086594235121 },
    "LD50_Zhu": { "0": 2.218288903488336 },
    "Solubility_AqSolDB": { "0": -0.4873699874413314 },
    "VDss_Lombardo": { "0": 2.288399805054195 },
    "Skin_Reaction": { "0": 0.6250560760498047 },
    "PPBR_AZ": { "0": -16.251700551897784 },
    "PAMPA_NCATS": { "0": 0.581823182106018 },
    "Pgp_Broccatelli": { "0": 0.0028498725732788 }
  },
  "summarized_admet_details": {
    "smiles": { "0": "NCC[C@@H]1CC[C@H]2CCC[C@H]2N1" },
    "filepath": { "0": "/home/CyberSecurity/drug_discovery_poc_v2/data/nvidia_diffdock_outputs/1U72/output/CHEMBL6640_output_9_rank01_confidence_-0.47.sdf" },
    "Absorption": { "0": 51.30670802636681 },
    "Distribution": { "0": 40.86855370298565 },
    "Metabolism": { "0": 70.49243892981777 },
    "Excretion": { "0": 13.842574641333847 },
    "Toxicity": { "0": 74.66459868165956 }
  }
};

const ADMETViewer: React.FC = () => {
  const [apiData, setApiData] = useState<APIResponse>(sampleAPIResponse);

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-600 bg-green-100 border-green-200';
    if (score >= 40) return 'text-yellow-600 bg-yellow-100 border-yellow-200';
    return 'text-red-600 bg-red-100 border-red-200';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 70) return 'Good';
    if (score >= 40) return 'Moderate';
    return 'Poor';
  };

  const getRiskColor = (value: number, isHighGood: boolean = false) => {
    const threshold1 = isHighGood ? 0.7 : 0.3;
    const threshold2 = isHighGood ? 0.4 : 0.6;
    
    if (isHighGood) {
      if (value >= threshold1) return 'text-green-600 bg-green-100';
      if (value >= threshold2) return 'text-yellow-600 bg-yellow-100';
      return 'text-red-600 bg-red-100';
    } else {
      if (value <= threshold1) return 'text-green-600 bg-green-100';
      if (value <= threshold2) return 'text-yellow-600 bg-yellow-100';
      return 'text-red-600 bg-red-100';
    }
  };

  const formatValue = (value: number, decimals: number = 3) => {
    return value.toFixed(decimals);
  };

  const formatPercentage = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const detailed = apiData.detailed_admet_details;
  const summarized = apiData.summarized_admet_details;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">ADMET Profile Analyzer</h1>
          <p className="text-lg text-gray-600">Comprehensive pharmacokinetic and toxicity assessment</p>
        </div>

        {/* Ligand Information */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2 text-blue-600" />
              Ligand Information
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">Compound ID</h3>
                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg font-mono">
                  {apiData.ligand}
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">SMILES</h3>
                <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg font-mono break-all">
                  {detailed.smiles["0"]}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ADMET Summary Scores */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-purple-600" />
              ADMET Summary Scores
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {Object.entries(summarized).map(([key, value]) => {
                if (key === 'smiles' || key === 'filepath') return null;
                const score = value["0"];
                return (
                  <div key={key} className={`p-4 rounded-lg border-2 ${getScoreColor(score)}`}>
                    <div className="text-center">
                      <h3 className="font-semibold text-sm mb-2">{key}</h3>
                      <div className="text-2xl font-bold mb-1">{formatValue(score, 1)}</div>
                      <div className="text-xs font-medium">{getScoreLabel(score)}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Detailed ADMET Data Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          
          {/* Molecular Properties */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Pill className="w-5 h-5 mr-2 text-purple-600" />
              Molecular Properties
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Molecular Weight</span>
                <span className="font-semibold">{formatValue(detailed.molecular_weight["0"], 2)} g/mol</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">LogP</span>
                <span className="font-semibold">{formatValue(detailed.logP["0"])}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">H-Bond Donors</span>
                <span className="font-semibold">{detailed.hydrogen_bond_donors["0"]}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">H-Bond Acceptors</span>
                <span className="font-semibold">{detailed.hydrogen_bond_acceptors["0"]}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">TPSA</span>
                <span className="font-semibold">{formatValue(detailed.tpsa["0"], 2)} Ų</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Lipinski Rule</span>
                <span className="font-semibold">{detailed.Lipinski["0"]}/4</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">QED Score</span>
                <span className="font-semibold">{formatValue(detailed.QED["0"])}</span>
              </div>
            </div>
          </div>

          {/* Absorption */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-green-600" />
              Absorption
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Human Intestinal Absorption</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.HIA_Hou["0"], true)}`}>
                  {formatPercentage(detailed.HIA_Hou["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Caco-2 Permeability</span>
                <span className="font-semibold">{formatValue(detailed.Caco2_Wang["0"])}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">P-gp Substrate</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.Pgp_Broccatelli["0"])}`}>
                  {formatPercentage(detailed.Pgp_Broccatelli["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Bioavailability</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.Bioavailability_Ma["0"], true)}`}>
                  {formatPercentage(detailed.Bioavailability_Ma["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">PAMPA Permeability</span>
                <span className="font-semibold">{formatValue(detailed.PAMPA_NCATS["0"])}</span>
              </div>
            </div>
          </div>

          {/* Distribution */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Activity className="w-5 h-5 mr-2 text-blue-600" />
              Distribution
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Blood-Brain Barrier</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.BBB_Martins["0"], true)}`}>
                  {formatPercentage(detailed.BBB_Martins["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Protein Binding</span>
                <span className="font-semibold">{formatValue(detailed.PPBR_AZ["0"])} %</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Volume of Distribution</span>
                <span className="font-semibold">{formatValue(detailed.VDss_Lombardo["0"])} L/kg</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Solubility</span>
                <span className="font-semibold">{formatValue(detailed.Solubility_AqSolDB["0"])} log S</span>
              </div>
            </div>
          </div>

          {/* Metabolism */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Zap className="w-5 h-5 mr-2 text-orange-600" />
              Metabolism
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">CYP1A2 Substrate</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.CYP1A2_Veith["0"])}`}>
                  {formatPercentage(detailed.CYP1A2_Veith["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">CYP2C19 Substrate</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.CYP2C19_Veith["0"])}`}>
                  {formatPercentage(detailed.CYP2C19_Veith["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">CYP2D6 Substrate</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.CYP2D6_Substrate_CarbonMangels["0"])}`}>
                  {formatPercentage(detailed.CYP2D6_Substrate_CarbonMangels["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">CYP3A4 Substrate</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.CYP3A4_Substrate_CarbonMangels["0"])}`}>
                  {formatPercentage(detailed.CYP3A4_Substrate_CarbonMangels["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Hepatic Clearance</span>
                <span className="font-semibold">{formatValue(detailed.Clearance_Hepatocyte_AZ["0"])} μL/min/10⁶</span>
              </div>
            </div>
          </div>

          {/* Excretion */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-indigo-600" />
              Excretion
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Half-life</span>
                <span className="font-semibold">{formatValue(detailed.Half_Life_Obach["0"])} h</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Summary Score</span>
                <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreColor(summarized.Excretion["0"])}`}>
                  {formatValue(summarized.Excretion["0"], 1)}
                </span>
              </div>
            </div>
          </div>

          {/* Toxicity */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-600" />
              Toxicity
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">AMES Mutagenicity</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.AMES["0"])}`}>
                  {formatPercentage(detailed.AMES["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Carcinogenicity</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.Carcinogens_Lagunin["0"])}`}>
                  {formatPercentage(detailed.Carcinogens_Lagunin["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">hERG Cardiotoxicity</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.hERG["0"])}`}>
                  {formatPercentage(detailed.hERG["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Hepatotoxicity (DILI)</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.DILI["0"])}`}>
                  {formatPercentage(detailed.DILI["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Clinical Toxicity</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.ClinTox["0"])}`}>
                  {formatPercentage(detailed.ClinTox["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Skin Sensitization</span>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskColor(detailed.Skin_Reaction["0"])}`}>
                  {formatPercentage(detailed.Skin_Reaction["0"])}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">LD50</span>
                <span className="font-semibold">{formatValue(detailed.LD50_Zhu["0"])} log(mg/kg)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Overall Assessment */}
        <div className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg p-6 text-white">
          <h3 className="text-2xl font-semibold mb-4 flex items-center">
            <Info className="w-6 h-6 mr-2" />
            Overall ADMET Assessment
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center">
                <TrendingUp className="w-4 h-4 mr-1" />
                Absorption
              </h4>
              <div className="text-2xl font-bold mb-1">{formatValue(summarized.Absorption["0"], 1)}</div>
              <p className="text-sm opacity-90">{getScoreLabel(summarized.Absorption["0"])} absorption profile</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center">
                <Activity className="w-4 h-4 mr-1" />
                Distribution
              </h4>
              <div className="text-2xl font-bold mb-1">{formatValue(summarized.Distribution["0"], 1)}</div>
              <p className="text-sm opacity-90">{getScoreLabel(summarized.Distribution["0"])} distribution</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center">
                <Zap className="w-4 h-4 mr-1" />
                Metabolism
              </h4>
              <div className="text-2xl font-bold mb-1">{formatValue(summarized.Metabolism["0"], 1)}</div>
              <p className="text-sm opacity-90">{getScoreLabel(summarized.Metabolism["0"])} metabolic profile</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                Excretion
              </h4>
              <div className="text-2xl font-bold mb-1">{formatValue(summarized.Excretion["0"], 1)}</div>
              <p className="text-sm opacity-90">{getScoreLabel(summarized.Excretion["0"])} clearance</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center">
                <Shield className="w-4 h-4 mr-1" />
                Toxicity
              </h4>
              <div className="text-2xl font-bold mb-1">{formatValue(summarized.Toxicity["0"], 1)}</div>
              <p className="text-sm opacity-90">{getScoreLabel(summarized.Toxicity["0"])} safety profile</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ADMETViewer;