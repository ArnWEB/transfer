import React from 'react';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  stepLabels: string[];
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  currentStep,
  totalSteps,
  stepLabels,
}) => {
  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        {stepLabels.map((label, index) => (
          <div key={index} className="flex items-center flex-1">
            <div className="flex flex-col items-center">
              <div
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center ey-body-sm font-semibold
                  ey-progress-step border-2
                  ${
                    index < currentStep
                      ? 'ey-progress-step completed'
                      : index === currentStep
                      ? 'ey-progress-step active'
                      : 'ey-progress-step inactive'
                  }
                `}
              >
                {index + 1}
              </div>
              <span
                className={`
                  mt-3 ey-caption font-medium text-center max-w-24
                  transition-colors duration-300
                  ${index <= currentStep ? 'text-primary' : 'text-muted-foreground'}
                `}
              >
                {label}
              </span>
            </div>
            {index < totalSteps - 1 && (
              <div className="flex-1 mx-4">
                <div
                  className={`
                    h-0.5 w-full
                    transition-all duration-300
                    ${index < currentStep ? 'bg-primary' : 'bg-border'}
                  `}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};