import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
  variant?: 'primary' | 'secondary' | 'outline' | 'destructive';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  className = '',
}) => {
  const baseClasses = `
    inline-flex items-center justify-center
    font-medium rounded-md
    transition-all duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-2
    disabled:opacity-50 disabled:cursor-not-allowed
    border focus-visible
  `;

  const variantClasses = {
    primary: 'ey-button-primary',
    secondary: 'ey-button-secondary', 
    outline: 'ey-button-outline',
    destructive: 'bg-destructive text-destructive-foreground border-destructive hover:bg-destructive/90 focus:ring-destructive/20',
  };

  const sizeClasses = {
    sm: 'px-4 py-2 ey-body-sm',
    md: 'px-6 py-3 ey-body',
    lg: 'px-8 py-4 ey-body-lg',
  };

  const isDisabled = disabled || loading;

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={isDisabled}
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
    >
      {loading ? (
        <LoadingSpinner size="sm" text="" />
      ) : (
        children
      )}
    </button>
  );
};