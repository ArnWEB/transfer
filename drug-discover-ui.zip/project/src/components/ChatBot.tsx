import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Lightbulb, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatBotProps {
  isOpen: boolean;
  onClose: () => void;
  onProteinSuggestion?: (pdbCode: string, smiles: string) => void;
  isIntegrated?: boolean;
}

export const ChatBot: React.FC<ChatBotProps> = ({ isOpen, onClose, onProteinSuggestion, isIntegrated = false }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm your protein research assistant. I can help you find the right target protein for your drug discovery analysis. What type of protein or disease target are you interested in?",
      isBot: true,
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    // Protein suggestions with PDB codes and reference molecules
    const proteinSuggestions = {
      'cancer': {
        response: "For cancer research, I recommend these well-studied targets:\n\n• **p53 (PDB: 1TUP)** - Tumor suppressor protein\n• **EGFR (PDB: 1M17)** - Epidermal growth factor receptor\n• **BCL-2 (PDB: 1GJH)** - Anti-apoptotic protein\n\nWould you like me to set up analysis for any of these?",
        suggestions: [
          { name: 'p53', pdb: '1TUP', smiles: 'CC(C)CC1=CC=C(C=C1)C(C)C(=O)O' },
          { name: 'EGFR', pdb: '1M17', smiles: 'CN1C=NC2=C1C(=O)N(C(=O)N2C)C' },
          { name: 'BCL-2', pdb: '1GJH', smiles: 'CC1=CC=C(C=C1)C(=O)NC2=CC=CC=C2' }
        ]
      },
      'diabetes': {
        response: "For diabetes research, these are excellent targets:\n\n• **Insulin Receptor (PDB: 1IR3)** - Key glucose metabolism regulator\n• **DPP-4 (PDB: 1N1M)** - Diabetes drug target\n• **PPAR-γ (PDB: 1FM6)** - Metabolic regulator\n\nWhich target interests you most?",
        suggestions: [
          { name: 'Insulin Receptor', pdb: '1IR3', smiles: 'CC(=O)NC1=CC=C(C=C1)O' },
          { name: 'DPP-4', pdb: '1N1M', smiles: 'CN1CCN(CC1)C(=O)C2=CC=CC=C2' },
          { name: 'PPAR-γ', pdb: '1FM6', smiles: 'CCCCCCCCCCCCCC(=O)O' }
        ]
      },
      'alzheimer': {
        response: "For Alzheimer's research, consider these important targets:\n\n• **Acetylcholinesterase (PDB: 1ACJ)** - Cholinergic system target\n• **Beta-secretase (PDB: 1FKN)** - Amyloid processing enzyme\n• **Tau Protein (PDB: 2MZ7)** - Neurofibrillary tangle target\n\nWhich would you like to analyze?",
        suggestions: [
          { name: 'Acetylcholinesterase', pdb: '1ACJ', smiles: 'CN(C)C(=O)OC1=CC=CC2=C1OC(C)(C)C2' },
          { name: 'Beta-secretase', pdb: '1FKN', smiles: 'CC1=CC=C(C=C1)S(=O)(=O)N' },
          { name: 'Tau Protein', pdb: '2MZ7', smiles: 'CC(C)CC1=CC=C(C=C1)C(C)C' }
        ]
      },
      'kinase': {
        response: "Kinases are excellent drug targets! Here are some popular ones:\n\n• **CDK2 (PDB: 1HCK)** - Cell cycle regulator\n• **p38 MAPK (PDB: 1A9U)** - Stress response kinase\n• **Aurora Kinase (PDB: 1MQ4)** - Mitotic kinase\n\nWhich kinase family interests you?",
        suggestions: [
          { name: 'CDK2', pdb: '1HCK', smiles: 'C1=CC=C(C=C1)NC(=O)C2=CC=CC=C2' },
          { name: 'p38 MAPK', pdb: '1A9U', smiles: 'CC1=CC=C(C=C1)C(=O)N' },
          { name: 'Aurora Kinase', pdb: '1MQ4', smiles: 'CN1C=NC2=C1C(=O)N(C(=O)N2C)C' }
        ]
      }
    };

    // Check for specific protein mentions
    for (const [key, data] of Object.entries(proteinSuggestions)) {
      if (lowerMessage.includes(key)) {
        return data.response;
      }
    }

    // General responses
    if (lowerMessage.includes('help') || lowerMessage.includes('start')) {
      return "I can help you find the perfect protein target! Tell me about:\n\n• Disease area (cancer, diabetes, Alzheimer's)\n• Protein family (kinases, receptors, enzymes)\n• Specific research goals\n\nWhat's your research focus?";
    }

    if (lowerMessage.includes('pdb') || lowerMessage.includes('code')) {
      return "PDB codes are 4-character identifiers for protein structures. For example:\n\n• 1ABC - A typical format\n• 2XYZ - Another example\n\nI can suggest specific PDB codes based on your research area. What disease or protein family are you studying?";
    }

    if (lowerMessage.includes('smiles')) {
      return "SMILES notation describes molecular structure. For drug discovery, I can suggest reference molecules that are known to interact with your target protein. What's your target protein or disease area?";
    }

    // Default response
    return "That's interesting! To give you the best protein recommendations, could you tell me more about:\n\n• Your research area or disease of interest\n• Type of protein you're looking for\n• Any specific requirements\n\nI have extensive knowledge of protein targets across many therapeutic areas!";
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = generateBotResponse(inputText);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse,
        isBot: true,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleProteinSelect = (pdb: string, smiles: string) => {
    if (onProteinSuggestion) {
      onProteinSuggestion(pdb, smiles);
      onClose();
    }
  };

  const quickSuggestions = [
    "Cancer targets",
    "Diabetes proteins", 
    "Alzheimer's targets",
    "Kinase proteins",
    "Help me choose"
  ];

  if (!isOpen) return null;

  const containerClasses = isIntegrated 
    ? "border border-border rounded-lg shadow-lg h-[600px] flex flex-col w-full"
    : "fixed inset-0 z-50 flex items-end justify-end p-4";

  const chatClasses = isIntegrated
    ? "w-full h-full"
    : "border border-border rounded-lg shadow-2xl w-96 h-[600px] flex flex-col";

  if (isIntegrated) {
    return (
      <div className="border border-border rounded-lg shadow-lg h-[600px] flex flex-col w-full" style={{ background: 'var(--background)' }}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-gradient-to-r from-primary/10 to-primary/5 rounded-t-lg flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center border-2 border-primary/30">
              <Bot className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="ey-heading-sm text-card-foreground">Protein Research Assistant</h3>
              <p className="ey-body-sm text-muted-foreground">AI-powered target discovery</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-destructive/10 hover:text-destructive rounded-md transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`flex items-start space-x-2 max-w-[80%] ${message.isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.isBot ? 'bg-primary/10' : 'bg-secondary'
                }`}>
                  {message.isBot ? (
                    <Bot className="w-4 h-4 text-primary" />
                  ) : (
                    <User className="w-4 h-4 text-secondary-foreground" />
                  )}
                </div>
                <div className={`rounded-lg p-3 ${
                  message.isBot 
                    ? 'bg-muted text-card-foreground' 
                    : 'bg-primary text-primary-foreground'
                }`}>
                  <div className="ey-body-sm">
                    {message.isBot ? (
                      <div className="prose prose-sm max-w-none dark:prose-invert prose-headings:text-card-foreground prose-p:text-card-foreground prose-strong:text-card-foreground prose-li:text-card-foreground prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1 prose-code:rounded">
                        <ReactMarkdown 
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            strong: ({ children }) => <strong className="font-semibold text-primary">{children}</strong>,
                            ul: ({ children }) => <ul className="list-disc list-inside space-y-1 ml-2">{children}</ul>,
                            li: ({ children }) => <li className="text-sm">{children}</li>,
                            code: ({ children }) => <code className="text-xs font-mono bg-primary/10 text-primary px-1 py-0.5 rounded">{children}</code>,
                          }}
                        >
                          {message.text}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-line">{message.text}</p>
                    )}
                  </div>
                  <p className="ey-caption text-xs mt-1 opacity-70">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="px-4 pb-2 border-t border-border bg-muted/20">
            <p className="ey-caption text-muted-foreground mb-3 pt-3">QUICK SUGGESTIONS:</p>
            <div className="flex flex-wrap gap-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setInputText(suggestion)}
                  className="px-3 py-1.5 bg-primary/10 text-primary border border-primary/20 rounded-full ey-body-sm hover:bg-primary/20 transition-colors font-medium"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-border bg-muted/10">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about protein targets..."
              className="flex-1 px-4 py-2.5 ey-input rounded-lg ey-body-sm border-2 focus:border-primary"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputText.trim()}
              className="px-4 py-2.5 ey-button-primary rounded-lg disabled:opacity-50 disabled:cursor-not-allowed shadow-sm hover:shadow-md transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={containerClasses} style={{ background: 'var(--background)' }}>
      <div className={chatClasses} style={{ background: 'var(--background)' }}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-primary/5 rounded-t-lg">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="ey-heading-sm text-card-foreground">Protein Research Assistant</h3>
              <p className="ey-body-sm text-muted-foreground">AI-powered target discovery</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-muted rounded-md transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`flex items-start space-x-2 max-w-[80%] ${message.isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.isBot ? 'bg-primary/10' : 'bg-secondary'
                }`}>
                  {message.isBot ? (
                    <Bot className="w-4 h-4 text-primary" />
                  ) : (
                    <User className="w-4 h-4 text-secondary-foreground" />
                  )}
                </div>
                <div className={`rounded-lg p-3 ${
                  message.isBot 
                    ? 'bg-muted text-card-foreground' 
                    : 'bg-primary text-primary-foreground'
                }`}>
                  <div className="ey-body-sm">
                    {message.isBot ? (
                      <div className="prose prose-sm max-w-none dark:prose-invert prose-headings:text-card-foreground prose-p:text-card-foreground prose-strong:text-card-foreground prose-li:text-card-foreground prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1 prose-code:rounded">
                        <ReactMarkdown 
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            strong: ({ children }) => <strong className="font-semibold text-primary">{children}</strong>,
                            ul: ({ children }) => <ul className="list-disc list-inside space-y-1 ml-2">{children}</ul>,
                            li: ({ children }) => <li className="text-sm">{children}</li>,
                            code: ({ children }) => <code className="text-xs font-mono bg-primary/10 text-primary px-1 py-0.5 rounded">{children}</code>,
                          }}
                        >
                          {message.text}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-line">{message.text}</p>
                    )}
                  </div>
                  <p className="ey-caption text-xs mt-1 opacity-70">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="px-4 pb-2">
            <p className="ey-caption text-muted-foreground mb-2">Quick suggestions:</p>
            <div className="flex flex-wrap gap-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setInputText(suggestion)}
                  className="px-3 py-1 bg-accent/10 text-accent border border-accent/20 rounded-full ey-body-sm hover:bg-accent/20 transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-border">
          <div className="flex space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about protein targets..."
              className="flex-1 px-3 py-2 ey-input rounded-md ey-body-sm"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputText.trim()}
              className="px-4 py-2 ey-button-primary rounded-md disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};