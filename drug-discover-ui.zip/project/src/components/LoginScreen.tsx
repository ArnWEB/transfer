import React from 'react';
import { FlaskConical, LogIn } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background transition-colors">
      <div className="backdrop-blur-lg bg-white/10 border border-white/20 rounded-2xl shadow-2xl p-16 flex flex-col items-center max-w-xl w-full">
        <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-8 shadow-lg">
          <FlaskConical className="w-10 h-10 text-primary" />
        </div>
        <h1 className="ey-heading-lg text-foreground mb-4 text-center">Welcome to Drug Discovery AI</h1>
        <p className="ey-body text-muted-foreground mb-10 text-center">Sign in to access the AI-powered pipeline for molecular analysis and drug discovery.</p>
        <button
          onClick={onLogin}
          className="w-full flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-white text-black font-semibold text-lg shadow-lg transition-all duration-200 border border-border hover:bg-primary hover:text-primary-foreground"
        >
          <LogIn className="w-6 h-6" />
          Login
        </button>
      </div>
    </div>
  );
};

export default LoginScreen; 