import React from 'react';
import { CheckCircle, AlertCircle, Info, Atom, TrendingUp } from 'lucide-react';
import { ApiResponse } from '../types';

interface ResultCardProps {
  response: ApiResponse;
}

export const ResultCard: React.FC<ResultCardProps> = ({ response }) => {
  const Icon = response.success ? CheckCircle : AlertCircle;
  const iconColor = response.success ? 'text-green-500' : 'text-destructive';
  const bgColor = response.success ? 'ey-status-success' : 'bg-red-100 dark:bg-red-900/20';

  return (
    <div className="ey-card p-6 space-y-6">
      <div className="flex items-start space-x-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${bgColor}`}>
          <Icon className={`w-6 h-6 ${iconColor}`} />
        </div>
        <div className="flex-1">
          <h3 className="ey-heading-sm text-card-foreground mb-2">
            Molecular Analysis Results
          </h3>
          <p className="ey-body text-muted-foreground">{response.message}</p>
        </div>
      </div>

      {response.data && (
        <div className="space-y-6">
          {response.data.analysisScore && (
            <div className="bg-accent/10 border border-accent/20 rounded-lg p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="ey-body font-semibold text-card-foreground">Analysis Confidence</span>
                </div>
                <span className="ey-heading-sm font-bold text-primary">
                  {response.data.analysisScore}%
                </span>
              </div>
              <div className="w-full bg-border rounded-full h-3">
                <div
                  className="bg-primary rounded-full h-3 transition-all duration-1000 ease-out"
                  style={{ width: `${response.data.analysisScore}%` }}
                />
              </div>
            </div>
          )}

          {(response.data.moleculesFound || response.data.topHits) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {response.data.moleculesFound && (
                <div className="bg-accent/10 border border-accent/20 rounded-lg p-5 text-center">
                  <div className="flex items-center justify-center mb-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Atom className="w-5 h-5 text-primary" />
                    </div>
                  </div>
                  <p className="ey-caption text-muted-foreground mb-1">MOLECULES SCREENED</p>
                  <p className="ey-heading-md font-bold text-primary">
                    {response.data.moleculesFound.toLocaleString()}
                  </p>
                </div>
              )}
              
              {response.data.topHits && (
                <div className="ey-status-success rounded-lg p-5 text-center">
                  <div className="flex items-center justify-center mb-3">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </div>
                  </div>
                  <p className="ey-caption text-muted-foreground mb-1">TOP CANDIDATES</p>
                  <p className="ey-heading-md font-bold text-green-600">
                    {response.data.topHits}
                  </p>
                </div>
              )}
            </div>
          )}

          {response.data.recommendations && (
            <div className="bg-muted/30 border border-border rounded-lg p-5">
              <h4 className="ey-body font-semibold text-card-foreground mb-4 flex items-center">
                <Info className="w-5 h-5 mr-2 text-primary" />
                AI Recommendations
              </h4>
              <ul className="space-y-3">
                {response.data.recommendations.map((rec: string, index: number) => (
                  <li key={index} className="flex items-start space-x-3">
                    <div className="ey-accent-dot mt-2 flex-shrink-0" />
                    <span className="ey-body-sm text-muted-foreground">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};