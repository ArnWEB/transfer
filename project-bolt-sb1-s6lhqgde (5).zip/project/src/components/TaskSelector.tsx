import React from 'react';
import { ChevronDown } from 'lucide-react';

interface TaskSelectorProps {
  selectedTask: string;
  onTaskChange: (task: string) => void;
}

const tasks = [
  'Extract text, class and bounding box',
  'Object detection',
  'Text extraction only',
  'Layout analysis',
  'Table extraction'
];

export const TaskSelector: React.FC<TaskSelectorProps> = ({ selectedTask, onTaskChange }) => {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-300">Tasks *</label>
      <div className="relative">
        <select
          value={selectedTask}
          onChange={(e) => onTaskChange(e.target.value)}
          className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white appearance-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-colors"
        >
          {tasks.map((task) => (
            <option key={task} value={task}>
              {task}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" size={20} />
      </div>
    </div>
  );
};