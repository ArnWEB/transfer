import React, { useState } from 'react';
import { ImageUpload } from './ImageUpload';
import { TaskSelector } from './TaskSelector';
import { ActionButtons } from './ActionButtons';
import { JsonInput } from './JsonInput';

interface InputPanelProps {
  onImageUpload: (file: File, imageUrls: string[], fileType: 'image' | 'pdf') => void;
  uploadedImages: string[];
  fileType: 'image' | 'pdf' | null;
  onRemoveImage: () => void;
  onAnalyze: () => void;
}

export const InputPanel: React.FC<InputPanelProps> = ({
  onImageUpload,
  uploadedImages,
  fileType,
  onRemoveImage,
  onAnalyze
}) => {
  const [selectedTask, setSelectedTask] = useState('Extract text, class and bounding box');
  const [isRunning, setIsRunning] = useState(false);
  const [activeTab, setActiveTab] = useState<'try' | 'python' | 'node' | 'shell'>('try');

  const handleRun = async () => {
    setIsRunning(true);
    await onAnalyze();
    setIsRunning(false);
  };

  const handleReset = () => {
    onRemoveImage();
    setSelectedTask('Extract text, class and bounding box');
  };

  const tabs = [
    { id: 'try' as const, label: 'Try' },
    { id: 'python' as const, label: 'Python' },
    { id: 'node' as const, label: 'Node' },
    { id: 'shell' as const, label: 'Shell' }
  ];
  return (
    <div className="h-full flex flex-col">
      {/* Header with tabs */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white">Input</h2>
        <div className="flex bg-gray-800 rounded-lg p-1 border border-gray-700">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1 rounded-md text-sm transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col gap-6">
        {activeTab === 'try' && (
          <>
            <ImageUpload
              onImageUpload={onImageUpload}
              uploadedImages={uploadedImages}
              fileType={fileType}
              onRemoveImage={onRemoveImage}
            />

            <TaskSelector
              selectedTask={selectedTask}
              onTaskChange={setSelectedTask}
            />
          </>
        )}
        
        {activeTab === 'python' && (
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h3 className="text-white font-medium mb-3">Python Code</h3>
            <pre className="text-sm text-gray-300 font-mono bg-gray-900 p-4 rounded overflow-x-auto">
{`import requests
import json
from pdf2image import convert_from_path

# API endpoint
url = "https://api.nvidia.com/v1/retrieval/nvidia/nemoretriever-parse"
        <div className="mt-auto">
          <ActionButtons
            onReset={handleReset}
            onRun={handleRun}
            isRunning={isRunning}
          />
        </div>

# Headers
headers = {
    "Authorization": "Bearer YOUR_API_KEY",
    "Content-Type": "application/json"
}
        {/* Footer */}
        <div className="text-xs text-gray-500 space-y-1">
          <p>
            <span className="font-medium">GOVERNING TERMS:</span> Access to this model is governed by the{' '}
# Request payload
payload = {
    "model": "nvidia/nemoretriever-parse",
    "messages": [
        {
            "role": "user",
            "content": "Extract text, class and bounding box"
        }
    ]
}
            <a href="#" className="text-emerald-400 hover:text-emerald-300">
# Make request
response = requests.post(url, headers=headers, json=payload)
result = response.json()
print(json.dumps(result, indent=2))`}
            </pre>
          </div>
        )}
        
        {activeTab === 'node' && (
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h3 className="text-white font-medium mb-3">Node.js Code</h3>
            <pre className="text-sm text-gray-300 font-mono bg-gray-900 p-4 rounded overflow-x-auto">
{`const fetch = require('node-fetch');

async function analyzeDocument() {
  const response = await fetch('https://api.nvidia.com/v1/retrieval/nvidia/nemoretriever-parse', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer YOUR_API_KEY',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'nvidia/nemoretriever-parse',
      messages: [{
        role: 'user',
        content: 'Extract text, class and bounding box'
      }]
    })
  });
  
  const result = await response.json();
  console.log(JSON.stringify(result, null, 2));
}

# Convert PDF to images if needed
def process_document(file_path):
    if file_path.endswith('.pdf'):
        images = convert_from_path(file_path)
        return [img for img in images]
    else:
        return [file_path]

analyzeDocument();`}
            </pre>
          </div>
        )}
        
        {activeTab === 'shell' && (
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h3 className="text-white font-medium mb-3">Shell/cURL Command</h3>
            <pre className="text-sm text-gray-300 font-mono bg-gray-900 p-4 rounded overflow-x-auto">
{`curl -X POST "https://api.nvidia.com/v1/retrieval/nvidia/nemoretriever-parse" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  // Convert PDF to images if needed
  const processDocument = async (filePath) => {
    if (filePath.endsWith('.pdf')) {
      const convert = pdf2pic.fromPath(filePath, {
        density: 100,
        saveFilename: "page",
        savePath: "./temp",
        format: "png",
        width: 600,
        height: 600
      });
      return await convert.bulk(-1);
    }
    return [filePath];
  };

  -d '{
    "model": "nvidia/nemoretriever-parse",
    "messages": [
      {
        "role": "user",
        "content": "Extract text, class and bounding box"
      }
    ]
  }' | jq .`}
            </pre>
          </div>
        )}
const pdf2pic = require('pdf2pic');

        {activeTab === 'try' && (
          <div className="mt-auto">
            <ActionButtons
              onReset={handleReset}
              onRun={handleRun}
              isRunning={isRunning}
            />
          </div>
        )}
      </div>
      
      {/* Footer */}
      <div className="text-xs text-gray-500 space-y-1 mt-4">
        <p>
          <span className="font-medium">GOVERNING TERMS:</span> Access to this model is governed by the{' '}
pdftoppm -png document.pdf page

# Then analyze each page
          <a href="#" className="text-emerald-400 hover:text-emerald-300">
            NVIDIA API Trial Terms of Service
          </a>
        </p>
      </div>
    </div>
  );
};