import React, { useState } from 'react';
import { PreviewTab } from './PreviewTab';
import { JsonTab } from './JsonTab';

interface OutputPanelProps {
  imageUrls: string[];
  fileType: 'image' | 'pdf' | null;
  analysisResults: any;
}

export const OutputPanel: React.FC<OutputPanelProps> = ({ imageUrls, fileType, analysisResults }) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'json'>('preview');

  const tabs = [
    { id: 'preview' as const, label: 'Preview' },
    { id: 'json' as const, label: 'JSON' }
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white">Output</h2>
        <div className="flex bg-gray-800 rounded-lg p-1 border border-gray-700">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        {activeTab === 'preview' ? (
          <PreviewTab 
            imageUrls={imageUrls}
            fileType={fileType}
            analysisResults={analysisResults} 
          />
        ) : (
          <JsonTab jsonData={analysisResults} />
        )}
      </div>
    </div>
  );
};