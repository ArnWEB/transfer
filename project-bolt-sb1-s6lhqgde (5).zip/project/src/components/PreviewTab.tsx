import React, { useState } from 'react';
import { BoundingBoxOverlay } from './BoundingBoxOverlay';
import { ElementsTable } from './ElementsTable';

interface PreviewTabProps {
  imageUrls: string[];
  fileType: 'image' | 'pdf' | null;
  analysisResults: any;
}

const extractDetectedElements = (analysisResults: any) => {
  if (!analysisResults) return [];
  
  if (analysisResults.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments) {
    try {
      const args = analysisResults.choices[0].message.tool_calls[0].function.arguments;
      if (typeof args === 'string') {
        const parsed = JSON.parse(args);
        return Array.isArray(parsed) && Array.isArray(parsed[0]) ? parsed[0] : [];
      }
      return Array.isArray(args) && Array.isArray(args[0]) ? args[0] : [];
    } catch (e) {
      console.warn('Failed to parse tool_calls arguments:', e);
    }
  }
  
  if (analysisResults.detectedElements) {
    return analysisResults.detectedElements;
  }
  
  return [];
};

export const PreviewTab: React.FC<PreviewTabProps> = ({ imageUrls, fileType, analysisResults }) => {
  const [currentPage, setCurrentPage] = useState(0);
  
  if (imageUrls.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400 bg-gray-800 rounded-lg border border-gray-700">
        <p>Upload an image or PDF to see the preview</p>
      </div>
    );
  }

  const detectedElements = extractDetectedElements(analysisResults);
  const currentImageUrl = imageUrls[currentPage];
  const isPdf = fileType === 'pdf';
  const totalPages = imageUrls.length;
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Detected Elements</h3>
        {isPdf && totalPages > 1 && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}
              className="px-3 py-1 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded transition-colors"
            >
              Previous
            </button>
            <span className="text-gray-300 text-sm">
              Page {currentPage + 1} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
              disabled={currentPage === totalPages - 1}
              className="px-3 py-1 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded transition-colors"
            >
              Next
            </button>
          </div>
        )}
      </div>
      
      <div className="bg-gray-800 rounded-lg p-4 border border-gray-700 max-h-[600px] overflow-auto">
        <BoundingBoxOverlay 
          imageUrl={currentImageUrl} 
          analysisResults={analysisResults} 
        />
      </div>
      
      {isPdf && totalPages > 1 && (
        <div className="flex justify-center">
          <div className="flex gap-2">
            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i)}
                className={`w-8 h-8 rounded text-sm transition-colors ${
                  currentPage === i
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Elements Table */}
      <ElementsTable analysisResults={analysisResults} />
      
      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-sm">
        {[
          { type: 'Page-header', color: 'bg-red-500' },
          { type: 'Section-header', color: 'bg-blue-500' },
          { type: 'Text', color: 'bg-green-500' },
          { type: 'Table', color: 'bg-purple-500' },
          { type: 'Page-footer', color: 'bg-orange-500' },
          { type: 'Image', color: 'bg-yellow-500' },
          { type: 'List', color: 'bg-pink-500' },
          { type: 'Code', color: 'bg-cyan-500' }
        ].map(({ type, color }) => (
          <div key={type} className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded ${color}`}></div>
            <span className="text-gray-300">{type}</span>
          </div>
        ))}
      </div>
    </div>
  );
};