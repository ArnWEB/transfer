import React from 'react';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface JsonTabProps {
  jsonData: any;
}

export const JsonTab: React.FC<JsonTabProps> = ({ jsonData }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(jsonData, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">JSON Output</h3>
        <button
          onClick={handleCopy}
          className="flex items-center gap-2 px-3 py-1 bg-gray-700 hover:bg-gray-600 text-white rounded transition-colors text-sm"
        >
          {copied ? <Check size={16} /> : <Copy size={16} />}
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-4 max-h-[600px] overflow-auto">
        <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono">
          <code>
            {JSON.stringify(jsonData, null, 2)}
          </code>
        </pre>
      </div>
    </div>
  );
};