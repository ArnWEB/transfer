import React, { useState } from 'react';

interface ElementsTableProps {
  analysisResults: any;
}

const extractDetectedElements = (analysisResults: any) => {
  if (!analysisResults) return [];
  
  if (analysisResults.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments) {
    try {
      const args = analysisResults.choices[0].message.tool_calls[0].function.arguments;
      if (typeof args === 'string') {
        const parsed = JSON.parse(args);
        return Array.isArray(parsed) && Array.isArray(parsed[0]) ? parsed[0] : [];
      }
      return Array.isArray(args) && Array.isArray(args[0]) ? args[0] : [];
    } catch (e) {
      console.warn('Failed to parse tool_calls arguments:', e);
    }
  }
  
  if (analysisResults.detectedElements) {
    return analysisResults.detectedElements;
  }
  
  return [];
};

export const ElementsTable: React.FC<ElementsTableProps> = ({ analysisResults }) => {
  const [activeTab, setActiveTab] = useState<'classes' | 'text'>('classes');
  const detectedElements = extractDetectedElements(analysisResults);

  if (detectedElements.length === 0) {
    return (
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="text-center text-gray-400">
          <p>No elements detected. Run analysis to see results.</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'classes' as const, label: 'Object Classes' },
    { id: 'text' as const, label: 'Parsed Text' }
  ];

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
      {/* Tab Headers */}
      <div className="flex border-b border-gray-700">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-gray-700 text-white border-b-2 border-emerald-500'
                : 'text-gray-400 hover:text-white hover:bg-gray-750'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="max-h-80 overflow-y-auto">
        {activeTab === 'classes' && (
          <div className="divide-y divide-gray-700">
            {detectedElements.map((element, index) => (
              <div key={index} className="flex items-center px-4 py-3 hover:bg-gray-750 transition-colors">
                <div className="flex-shrink-0 w-32">
                  <span className="inline-block px-3 py-1 text-xs font-medium bg-gray-700 text-gray-300 rounded-full">
                    {element.type}
                  </span>
                </div>
                <div className="flex-1 ml-4">
                  <p className="text-sm text-gray-300 line-clamp-2">
                    {element.text || 'No text content'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'text' && (
          <div className="divide-y divide-gray-700">
            {detectedElements.map((element, index) => (
              <div key={index} className="px-4 py-3 hover:bg-gray-750 transition-colors">
                <div className="flex items-start gap-3">
                  <span className="inline-block px-2 py-1 text-xs font-medium bg-emerald-600 text-white rounded flex-shrink-0 mt-1">
                    {element.type}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-300 whitespace-pre-wrap break-words">
                      {element.text || 'No text content'}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};