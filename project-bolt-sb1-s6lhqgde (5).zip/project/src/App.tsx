import React, { useState } from 'react';
import { InputPanel } from './components/InputPanel';
import { OutputPanel } from './components/OutputPanel';

// Sample analysis results based on the provided JSON structure
const sampleAnalysisResults = {
  "id": "chat-1618eb987f844bc5b3be4c8517f599c1",
  "object": "chat.completion",
  "created": 1753179054,
  "model": "nvidia/nemoretriever-parse",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": null,
        "tool_calls": [
          {
            "id": "chatcmpl-tool-ca80f05c7f0b4cbbbb3880daef35d872",
            "type": "function",
            "function": {
              "name": "markdown_bbox",
              "arguments": "[[{\"bbox\": {\"xmin\": 0.04749318600368331, \"ymin\": 0.0021333333333333946, \"xmax\": 0.9692198895027624, \"ymax\": 0.10426666666666673}, \"text\": \"Labsmart Software Sample Letterhead Regd. No.: XXXX54826XX\", \"type\": \"Page-header\"}, {\"bbox\": {\"xmin\": 0.029586740331491744, \"ymin\": 0.14373333333333335, \"xmax\": 0.24021510128913456, \"ymax\": 0.16666666666666666}, \"text\": \"Mr. Saubhik Bhaumik\", \"type\": \"Section-header\"}, {\"bbox\": {\"xmin\": 0.008948802946592978, \"ymin\": 0.6728, \"xmax\": 0.36161473296500923, \"ymax\": 0.6957333333333334}, \"text\": \"Possible causes of abnormal parameters:\", \"type\": \"Section-header\"}, {\"bbox\": {\"xmin\": -0.002887661141804758, \"ymin\": 0.1584, \"xmax\": 0.222308655616943, \"ymax\": 0.23546666666666663}, \"text\": \"\\\\begin{tabular}{cc}\\nAge / Sex & : 27 YRS / M\\\\\\\\\\nReferred by : & Self\\\\\\\\\\nReg. no. & : 1001\\\\\\\\\\n\\\\end{tabular}\\n\", \"type\": \"Table\"}, {\"bbox\": {\"xmin\": 0.020785267034990715, \"ymin\": 0.29173333333333334, \"xmax\": 0.9749863720073665, \"ymax\": 0.5832}, \"text\": \"\\\\begin{tabular}{cccc}\\n**TEST** & **VALUE** & **UNIT** & **REFERENCE**\\\\\\\\\\nHEMOGLOBIN & 15 & g/dl & 13 - 17\\\\\\\\\\nTOTAL LEUKOCYTE COUNT & 5,100 & cumm & 4,800 - 10,800\\\\\\\\\\nDIFFERENTIAL LEUOCYTE COUNT &  &  & \\\\\\\\\\nNEUTROPHILS & 79 & % & 40 - 80\\\\\\\\\\nLYMPHOCYTE & L & 18 & %\\\\\\\\\\nEOSINOPHILS & 1 & % & 1 - 6\\\\\\\\\\nMONOCYTES & L & 1 & % 2 - 10\\\\\\\\\\nBASOPHILS & 1 & % & < 2\\\\\\\\\\nPLATELET COUNT & 3.5 & lakhs/cumm  & 1.5 - 4.1\\\\\\\\\\nTOTAL RBC COUNT & 5 & million/cumm & 4.5 - 5.5\\\\\\\\\\nHEMATOCRIT VALUE, HCT & 42 & % & 40 - 50\\\\\\\\\\nMEAN CORPUSCULAR VOLUME, MCV & 84.0 & IL & 83 - 101\\\\\\\\\\nMEAN CELL HAEMOGLOBIN, MCH & 30.0 & Pg & 27 - 32\\\\\\\\\\nMEAN CELL HAEMOGLOBIN CON, MCHC H & 35.7 & % & 31.5 - 34.5\\\\\\\\\\n\\\\end{tabular}\\n\", \"type\": \"Table\"}, {\"bbox\": {\"xmin\": 0.03869171270718228, \"ymin\": 0.6938666666666666, \"xmax\": 0.9604184162062616, \"ymax\": 0.7853333333333333}, \"text\": \"\\\\begin{tabular}{cccc}\\n & **High** &  & **Low**\\\\\\\\\\n**RBC, Hb, or HCT** & **Dehydration, polycythemia, shock, chronic hypoxia** &  & **Anemia, thalassemia, and other hemoglobinopathies**\\\\\\\\\\nMCV & Macrocytic anemia, liver disease &  & Microytic anemia\\\\\\\\\\nWBC & Acute stress, infection, malignancies &  & Sepsis, marrow hypoplasia\\\\\\\\\\nPlatelets & Risk of thrombosis &  & Risk of bleeding\\\\\\\\\\n\\\\end{tabular}\\n\", \"type\": \"Table\"}, {\"bbox\": {\"xmin\": 0.4978858195211786, \"ymin\": -0.004266666666666641, \"xmax\": 0.9871263351749541, \"ymax\": 0.13120000000000007}, \"text\": \"- Regd. No.: XXXx54826XX Przyter from Coordnet\", \"type\": \"Caption\"}, {\"bbox\": {\"xmin\": 0.6727012891344383, \"ymin\": 0.2333333333333334, \"xmax\": 0.7646615101289134, \"ymax\": 0.23946666666666663}, \"text\": \"1001 Registered on : 17/10/2024 04:55 PM Collected on : 17/10/2024 Received on : 17/10/2024 Reported on : 17/10/2024 04:55 PM\", \"type\": \"Caption\"}, {\"bbox\": {\"xmin\": 0.8478202578268874, \"ymin\": 0.15626666666666664, \"xmax\": 0.9246055248618784, \"ymax\": 0.16880000000000006}, \"text\": \"Prep for Year to Partries\", \"type\": \"Caption\"}, {\"bbox\": {\"xmin\": 0.03262173112338866, \"ymin\": 0.9021333333333335, \"xmax\": 0.8921311233885821, \"ymax\": 0.9728}, \"text\": \"NOT VALID FOR MEDICO LEGAL PURPOSE Work timings: Monday to Sunday, 8 am to 8 pm Please correlate clinically. Although the test results are checked thoroughly, in case of any unexpected test results which could be due to machine error or typing error or any other reason please contact the lab immediately for a free evaluation.\", \"type\": \"Caption\"}, {\"bbox\": {\"xmin\": 0.03565672191528557, \"ymin\": 0.8583999999999999, \"xmax\": 0.9631499079189685, \"ymax\": 0.8874666666666666}, \"text\": \"Mr. Sachin Sharma DMLT, Lab Incharge Page 1 of 2 Dr. A. K. Asthana MBBS, MD Pathologist\", \"type\": \"Caption\"}]]"
            }
          }
        ]
      },
      "logprobs": null,
      "finish_reason": "stop",
      "stop_reason": null
    }
  ],
  "usage": {
    "prompt_tokens": 5,
    "total_tokens": 979,
    "completion_tokens": 974
  },
  "prompt_logprobs": null
};

function App() {
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [fileType, setFileType] = useState<'image' | 'pdf' | null>(null);
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  const handleImageUpload = (file: File, imageUrls: string[], type: 'image' | 'pdf') => {
    setUploadedImages(imageUrls);
    setFileType(type);
    setAnalysisResults(null);
  };

  const handleRemoveImage = () => {
    setUploadedImages([]);
    setFileType(null);
    setAnalysisResults(null);
  };

  const handleAnalyze = async () => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Set sample results
    setAnalysisResults(sampleAnalysisResults);
  };
  return (
    <div className="min-h-screen bg-gray-900">
      <div className="container mx-auto px-6 py-8 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-[calc(100vh-4rem)]">
          {/* Input Panel */}
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 shadow-2xl">
            <InputPanel
              onImageUpload={handleImageUpload}
              uploadedImages={uploadedImages}
              fileType={fileType}
              onRemoveImage={handleRemoveImage}
              onAnalyze={handleAnalyze}
            />
          </div>

          {/* Output Panel */}
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 shadow-2xl">
            <OutputPanel
              imageUrls={uploadedImages}
              fileType={fileType}
              analysisResults={analysisResults}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;