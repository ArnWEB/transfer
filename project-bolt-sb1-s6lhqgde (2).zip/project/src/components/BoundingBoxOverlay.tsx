import React from 'react';

interface BoundingBoxOverlayProps {
  imageUrl: string;
  analysisResults: any;
}

const getTypeColor = (type: string) => {
  const colors = {
    'Page-header': 'border-red-500 bg-red-500',
    'Section-header': 'border-blue-500 bg-blue-500',
    'Text': 'border-green-500 bg-green-500',
    'Table': 'border-purple-500 bg-purple-500',
    'Page-footer': 'border-orange-500 bg-orange-500',
    'Image': 'border-yellow-500 bg-yellow-500',
    'List': 'border-pink-500 bg-pink-500',
    'Code': 'border-cyan-500 bg-cyan-500'
  };
  return colors[type as keyof typeof colors] || 'border-gray-500 bg-gray-500';
};

const extractDetectedElements = (analysisResults: any) => {
  if (!analysisResults) return [];
  
  if (analysisResults.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments) {
    try {
      const args = analysisResults.choices[0].message.tool_calls[0].function.arguments;
      if (typeof args === 'string') {
        const parsed = JSON.parse(args);
        // The parsed result is a nested array, so we need to access the first element
        return Array.isArray(parsed) && Array.isArray(parsed[0]) ? parsed[0] : [];
      }
      return Array.isArray(args) && Array.isArray(args[0]) ? args[0] : [];
    } catch (e) {
      console.warn('Failed to parse tool_calls arguments:', e);
    }
  }
  
  // Handle direct detectedElements array
  if (analysisResults.detectedElements) {
    return analysisResults.detectedElements;
  }
  
  return [];
};

export const BoundingBoxOverlay: React.FC<BoundingBoxOverlayProps> = ({ 
  imageUrl, 
  analysisResults 
}) => {
  const detectedElements = extractDetectedElements(analysisResults);
  
  return (
    <div className="relative inline-block">
      <img 
        src={imageUrl} 
        alt="Document analysis" 
        className="max-w-full max-h-[600px] object-contain rounded-lg"
      />
      
      {/* Bounding boxes overlay */}
      <div className="absolute inset-0">
        {detectedElements.map((element, index) => {
          const bbox = element.bbox;
          if (!bbox) return null;
          
          const colorClass = getTypeColor(element.type);
          
          return (
            <div
              key={index}
              className={`absolute border-2 ${colorClass.split(' ')[0]} ${colorClass.split(' ')[1]} bg-opacity-20 pointer-events-none`}
              style={{
                left: `${bbox.xmin * 100}%`,
                top: `${bbox.ymin * 100}%`,
                width: `${(bbox.xmax - bbox.xmin) * 100}%`,
                height: `${(bbox.ymax - bbox.ymin) * 100}%`,
              }}
            >
              <div className={`absolute -top-6 left-0 px-2 py-1 text-xs text-white rounded text-shadow ${colorClass.split(' ')[1]}`}>
                {element.type}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};