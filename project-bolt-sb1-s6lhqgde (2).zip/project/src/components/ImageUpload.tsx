import React, { useCallback, useState } from 'react';
import { Upload, Image as ImageIcon, X } from 'lucide-react';

interface ImageUploadProps {
  onImageUpload: (file: File, imageUrls: string[], fileType: 'image' | 'pdf') => void;
  uploadedImages: string[];
  fileType: 'image' | 'pdf' | null;
  onRemoveImage: () => void;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ 
  onImageUpload, 
  uploadedImages,
  fileType,
  onRemoveImage 
}) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const convertPdfToImages = async (file: File): Promise<string[]> => {
    // For demo purposes, we'll simulate PDF conversion
    // In a real implementation, you'd use a PDF-to-image conversion library
    return new Promise((resolve) => {
      setTimeout(() => {
        // Simulate multiple pages with placeholder images
        const pageCount = Math.floor(Math.random() * 5) + 2; // 2-6 pages
        const imageUrls = Array.from({ length: pageCount }, (_, i) => 
          `https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop&page=${i + 1}`
        );
        resolve(imageUrls);
      }, 1000);
    });
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        const imageUrl = URL.createObjectURL(file);
        onImageUpload(file, [imageUrl], 'image');
      } else if (file.type === 'application/pdf') {
        convertPdfToImages(file).then(imageUrls => {
          onImageUpload(file, imageUrls, 'pdf');
        });
      }
    }
  }, [onImageUpload]);

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        const imageUrl = URL.createObjectURL(file);
        onImageUpload(file, [imageUrl], 'image');
      } else if (file.type === 'application/pdf') {
        const imageUrls = await convertPdfToImages(file);
        onImageUpload(file, imageUrls, 'pdf');
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-gray-300">Upload Image *</label>
      </div>
      
      {uploadedImages.length > 0 ? (
        <div className="relative group">
          <img 
            src={uploadedImages[0]} 
            alt={`Uploaded ${fileType}`} 
            className="w-full max-h-96 object-contain rounded-lg border border-gray-700 bg-gray-800"
          />
          <button
            onClick={onRemoveImage}
            className="absolute top-2 right-2 p-1 bg-red-500 hover:bg-red-600 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <X size={16} />
          </button>
          <div className="absolute bottom-2 left-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs">
            {fileType === 'pdf' ? `PDF (${uploadedImages.length} pages)` : 'Image'}
          </div>
        </div>
      ) : (
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
            isDragOver 
              ? 'border-emerald-500 bg-emerald-500 bg-opacity-10' 
              : 'border-gray-600 hover:border-gray-500'
          }`}
        >
          <ImageIcon className="mx-auto mb-4 text-gray-500" size={48} />
          <p className="text-gray-400 mb-4">
            Drag & drop an image here, or click to browse
          </p>
          <input
            type="file"
            accept="image/*,application/pdf"
            onChange={handleFileInput}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg cursor-pointer transition-colors"
          >
            <Upload size={16} />
            Upload
          </label>
          <div className="text-xs text-gray-500 mt-4">
            jpg, jpeg, png, pdf
          </div>
        </div>
      )}
    </div>
  );
};