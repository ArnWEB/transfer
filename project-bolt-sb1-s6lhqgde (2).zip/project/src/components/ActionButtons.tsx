import React from 'react';
import { RotateCcw, Play } from 'lucide-react';

interface ActionButtonsProps {
  onReset: () => void;
  onRun: () => void;
  isRunning?: boolean;
}

export const ActionButtons: React.FC<ActionButtonsProps> = ({ 
  onReset, 
  onRun, 
  isRunning = false 
}) => {
  return (
    <div className="flex gap-3">
      <button
        onClick={onReset}
        className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
      >
        <RotateCcw size={16} />
        Reset
      </button>
      <button
        onClick={onRun}
        disabled={isRunning}
        className="flex-1 px-4 py-3 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-all flex items-center justify-center gap-2 font-medium"
      >
        <Play size={16} />
        {isRunning ? 'Running...' : 'Run'}
      </button>
    </div>
  );
};