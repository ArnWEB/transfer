import React from 'react';
import { MessageCircle, Lightbulb } from 'lucide-react';

interface ChatBotToggleProps {
  onClick: () => void;
}

export const ChatBotToggle: React.FC<ChatBotToggleProps> = ({ onClick }) => {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-6 right-6 w-14 h-14 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center z-40 group"
      aria-label="Open protein research assistant"
    >
      <div className="relative">
        <MessageCircle className="w-6 h-6" />
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
      </div>
      
      {/* Tooltip */}
      <div className="absolute right-16 bottom-2 bg-card border border-border rounded-lg px-3 py-2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap">
        <div className="flex items-center space-x-2">
          <Lightbulb className="w-4 h-4 text-primary" />
          <span className="ey-body-sm text-card-foreground">Need help choosing a protein target?</span>
        </div>
        <div className="absolute top-1/2 -right-1 transform -translate-y-1/2 w-2 h-2 bg-card border-r border-b border-border rotate-45"></div>
      </div>
    </button>
  );
};