import React from 'react';

interface FormInputProps {
  label: string;
  type?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  multiline?: boolean;
  rows?: number;
  compact?: boolean;
}

export const FormInput: React.FC<FormInputProps> = ({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  required = false,
  disabled = false,
  error,
  multiline = false,
  rows = 3,
  compact = false,
}) => {
  const baseClasses = `
    w-full 
    ${compact ? 'px-3 py-2' : 'px-4 py-3'}
    ey-input
    rounded-md
    transition-all duration-200
    disabled:opacity-50 disabled:cursor-not-allowed
    font-medium
    ${compact ? 'text-sm' : ''}
  `;

  const errorClasses = error ? 'border-destructive focus:ring-destructive/20 focus:border-destructive' : '';

  return (
    <div className={`space-y-${compact ? '1' : '2'}`}>
      <label className={`block ey-caption text-muted-foreground font-medium ${compact ? 'text-xs' : ''}`}>
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </label>
      
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          rows={rows}
          className={`${baseClasses} ${errorClasses} resize-none`}
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          className={`${baseClasses} ${errorClasses}`}
        />
      )}
      
      {error && (
        <p className={`${compact ? 'ey-body-sm text-xs' : 'ey-body-sm'} text-destructive font-medium`}>{error}</p>
      )}
    </div>
  );
};