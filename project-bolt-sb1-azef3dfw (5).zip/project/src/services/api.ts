import { FormData, ApiResponse, SecondStepData } from '../types';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock API service for the drug discovery pipeline
export const submitInitialForm = async (data: FormData): Promise<ApiResponse> => {
  await delay(3000); // Simulate computational analysis delay
  
  // Randomly determine if optimization is needed based on analysis results
  const needsOptimization = Math.random() > 0.4; // 60% chance needs optimization
  
  const baseResponse = {
    success: true,
    requiresOptimization: needsOptimization,
    data: {
      analysisId: 'dd_' + Math.random().toString(36).substr(2, 9),
      analysisScore: Math.floor(Math.random() * 30) + 70, // 70-100
      moleculesFound: Math.floor(Math.random() * 500) + 100,
      topHits: Math.floor(Math.random() * 20) + 5,
    }
  };

  if (needsOptimization) {
    // Results suggest optimization would be beneficial
    return {
      ...baseResponse,
      message: 'Initial analysis completed! The AI has identified potential improvements through parameter optimization.',
      data: {
        ...baseResponse.data,
        recommendations: [
          'Similarity threshold could be fine-tuned for better hit rates',
          'Fingerprinting resolution optimization may improve accuracy',
          'Additional molecular filters could enhance selectivity',
          'ADMET property constraints would refine candidate quality',
        ],
      },
      suggestions: [
        'Would you like to optimize molecular filtering parameters?',
        'Should I refine the similarity search criteria?',
        'Would you prefer to add pharmacokinetic constraints?',
      ],
    };
  } else {
    // Results are optimal, skip optimization
    return {
      ...baseResponse,
      message: 'Excellent results achieved! The AI analysis has identified high-quality drug candidates with optimal parameters.',
      data: {
        ...baseResponse.data,
        analysisScore: Math.floor(Math.random() * 15) + 85, // Higher scores for direct results
        recommendations: [
          'Current parameters are well-optimized for your target',
          'High-confidence molecular matches identified',
          'Binding affinity predictions show strong potential',
          'ADMET profiles indicate favorable drug-like properties',
        ],
        finalReport: 'Comprehensive analysis completed with optimal results.',
        nextSteps: [
          'Review the detailed molecular analysis report',
          'Download high-resolution molecular structures',
          'Schedule expert consultation for lead validation',
          'Begin experimental screening of top candidates',
        ],
        deliverables: [
          'Molecular similarity matrix and clustering analysis',
          'Top drug candidate profiles with confidence scores',
          'Binding affinity predictions and interaction maps',
          'Drug-likeness and synthetic accessibility reports',
        ],
      },
    };
  }
};

// Mock API service for the follow-up analysis
export const submitFollowUp = async (data: SecondStepData): Promise<ApiResponse> => {
  await delay(2000); // Simulate additional computational analysis
  
  return {
    success: true,
    message: 'Optimization complete! Enhanced drug discovery analysis has identified superior molecular candidates.',
    data: {
      finalReport: 'Advanced AI optimization has refined the analysis with your specified parameters, resulting in improved candidate selection.',
      nextSteps: [
        'Review the optimized molecular analysis report',
        'Download enhanced molecular structures and properties',
        'Schedule expert consultation for optimized lead compounds',
        'Begin targeted experimental validation',
      ],
      deliverables: [
        'Optimized molecular similarity matrix with enhanced clustering',
        'Refined drug candidate profiles with improved ADMET predictions',
        'Enhanced binding affinity scores and detailed interaction maps',
        'Comprehensive synthetic accessibility and optimization reports',
      ],
    },
  };
};