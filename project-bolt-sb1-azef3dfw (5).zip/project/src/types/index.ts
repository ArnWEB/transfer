export interface FormData {
  rcsbPdbCode: string;
  referenceMoleculeSmiles: string;
  similarityThreshold: string;
  fingerprintingResolution: string;
}

export interface ApiResponse {
  success: boolean;
  message: string;
  data?: any;
  suggestions?: string[];
  requiresOptimization?: boolean; // New field to determine if optimization is needed
}

export interface SecondStepData {
  followUp: string;
}

export type FormStep = 'initial' | 'processing' | 'followup' | 'completed';