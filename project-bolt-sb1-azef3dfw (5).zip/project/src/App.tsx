import React, { useState, useEffect } from 'react';
import { Atom, Sparkles, FlaskConical, User } from 'lucide-react';
import { FormData, ApiResponse, SecondStepData, FormStep } from './types';
import { FormInput } from './components/FormInput';
import { Button } from './components/Button';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ProgressBar } from './components/ProgressBar';
import { ResultCard } from './components/ResultCard';
import { ThemeToggle } from './components/ThemeToggle';
import { ChatBot } from './components/ChatBot';
import { ChatBotToggle } from './components/ChatBotToggle';
import { submitInitialForm, submitFollowUp } from './services/api';

function App() {
  const [isDark, setIsDark] = useState(true); // Default to dark theme
  const [currentStep, setCurrentStep] = useState<FormStep>('initial');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    rcsbPdbCode: '',
    referenceMoleculeSmiles: '',
    similarityThreshold: '',
    fingerprintingResolution: '',
  });
  const [followUpData, setFollowUpData] = useState<SecondStepData>({
    followUp: '',
  });
  const [selectedRecommendation, setSelectedRecommendation] = useState<string>('');
  const [apiResponse, setApiResponse] = useState<ApiResponse | null>(null);
  const [finalResponse, setFinalResponse] = useState<ApiResponse | null>(null);
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [isLoading, setIsLoading] = useState(false);

  // Dynamic step labels based on whether optimization is needed
  const getStepLabels = (): string[] => {
    if (apiResponse?.requiresOptimization === false) {
      return ['Pipeline Setup', 'AI Processing', 'Results'];
    }
    return ['Pipeline Setup', 'AI Processing', 'Optimization', 'Results'];
  };

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [isDark]);

  const validateForm = (): boolean => {
    const newErrors: Partial<FormData> = {};
    
    if (!formData.rcsbPdbCode.trim()) {
      newErrors.rcsbPdbCode = 'RCSB PDB Code is required';
    } else if (!/^[0-9][A-Za-z0-9]{3}$/i.test(formData.rcsbPdbCode.trim())) {
      newErrors.rcsbPdbCode = 'Invalid PDB format (e.g., 1ABC)';
    }
    
    if (!formData.referenceMoleculeSmiles.trim()) {
      newErrors.referenceMoleculeSmiles = 'Reference molecule SMILES is required';
    }
    
    if (!formData.similarityThreshold.trim()) {
      newErrors.similarityThreshold = 'Similarity threshold is required';
    } else {
      const threshold = parseFloat(formData.similarityThreshold);
      if (isNaN(threshold) || threshold < 0 || threshold > 1) {
        newErrors.similarityThreshold = 'Threshold must be between 0 and 1';
      }
    }
    
    if (!formData.fingerprintingResolution.trim()) {
      newErrors.fingerprintingResolution = 'Fingerprinting resolution is required';
    } else {
      const resolution = parseInt(formData.fingerprintingResolution);
      if (isNaN(resolution) || resolution < 1 || resolution > 4096) {
        newErrors.fingerprintingResolution = 'Resolution must be between 1 and 4096';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitInitial = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    setCurrentStep('processing');
    
    try {
      const response = await submitInitialForm(formData);
      setApiResponse(response);
      
      // Decide next step based on AI response
      if (response.requiresOptimization) {
        setCurrentStep('followup'); // Go to optimization
      } else {
        setFinalResponse(response); // Skip optimization, go directly to results
        setCurrentStep('completed');
      }
    } catch (error) {
      console.error('API Error:', error);
      setApiResponse({
        success: false,
        message: 'An error occurred during molecular analysis. Please check your parameters and try again.',
        requiresOptimization: false,
      });
      setCurrentStep('completed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedRecommendation) return;
    
    setIsLoading(true);
    
    try {
      const response = await submitFollowUp({ followUp: selectedRecommendation });
      setFinalResponse(response);
      setCurrentStep('completed');
    } catch (error) {
      console.error('API Error:', error);
      setFinalResponse({
        success: false,
        message: 'An error occurred during follow-up analysis. Please try again.',
      });
      setCurrentStep('completed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setCurrentStep('initial');
    setFormData({
      rcsbPdbCode: '',
      referenceMoleculeSmiles: '',
      similarityThreshold: '',
      fingerprintingResolution: '',
    });
    setFollowUpData({ followUp: '' });
    setSelectedRecommendation('');
    setApiResponse(null);
    setFinalResponse(null);
    setErrors({});
  };

  const handleSkipOptimization = () => {
    if (apiResponse) {
      setFinalResponse(apiResponse);
      setCurrentStep('completed');
    }
  };

  const handleProteinSuggestion = (pdbCode: string, smiles: string) => {
    setFormData(prev => ({
      ...prev,
      rcsbPdbCode: pdbCode,
      referenceMoleculeSmiles: smiles,
    }));
  };

  const getCurrentStepIndex = (): number => {
    const stepLabels = getStepLabels();
    switch (currentStep) {
      case 'initial': return 0;
      case 'processing': return 1;
      case 'followup': return stepLabels.length === 3 ? 2 : 2; // Optimization step
      case 'completed': return stepLabels.length - 1; // Last step (Results)
      default: return 0;
    }
  };

  return (
    <div className="min-h-screen ey-gradient-bg">
      {/* Compact Header */}
      <div className="bg-profile-bg border-b border-border">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-ey-yellow rounded-full flex items-center justify-center">
                <FlaskConical className="w-5 h-5 text-ey-primary-dark" />
              </div>
              <div>
                <h2 className="ey-heading-sm text-foreground">AI Powered Drug Discovery Pipeline</h2>
                <p className="ey-body-sm text-muted-foreground">Computational Chemistry & Molecular Analysis</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <ThemeToggle isDark={isDark} onToggle={() => setIsDark(!isDark)} />
              <span className="text-foreground ey-body-sm">researcher@drugdiscovery.ai</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-6 max-w-7xl">
        {/* Compact Progress Section */}
        <div className="mb-6">
          <ProgressBar
            currentStep={getCurrentStepIndex()}
            totalSteps={getStepLabels().length}
            stepLabels={getStepLabels()}
          />
        </div>

        {/* Main Content Card */}
        <div className="ey-card p-6">
          {currentStep === 'processing' && (
            <div className="text-center py-8">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Atom className="w-8 h-8 text-primary ey-pulse" />
                </div>
              </div>
              <LoadingSpinner size="lg" text="Running molecular analysis..." />
              <h3 className="ey-heading-md text-card-foreground mt-4 mb-3">
                AI Processing in Progress
              </h3>
              <p className="ey-body text-muted-foreground max-w-2xl mx-auto mb-6">
                Our advanced AI system is analyzing your protein structure and performing 
                similarity screening against comprehensive molecular databases.
              </p>
              
              <div className="ey-analysis-grid rounded-lg p-4 max-w-3xl mx-auto">
                <div className="grid grid-cols-4 gap-4">
                  <div className="ey-metric-card p-3 text-center">
                    <p className="ey-caption text-muted-foreground mb-1">PDB STRUCTURE</p>
                    <p className="ey-body font-medium text-card-foreground">
                      {formData.rcsbPdbCode.toUpperCase()}
                    </p>
                  </div>
                  <div className="ey-metric-card p-3 text-center">
                    <p className="ey-caption text-muted-foreground mb-1">THRESHOLD</p>
                    <p className="ey-body font-medium text-card-foreground">
                      {formData.similarityThreshold}
                    </p>
                  </div>
                  <div className="ey-metric-card p-3 text-center">
                    <p className="ey-caption text-muted-foreground mb-1">RESOLUTION</p>
                    <p className="ey-body font-medium text-card-foreground">
                      {formData.fingerprintingResolution}
                    </p>
                  </div>
                  <div className="ey-metric-card p-3 text-center">
                    <p className="ey-caption text-muted-foreground mb-1">STATUS</p>
                    <p className="ey-body font-medium text-primary">Processing</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentStep === 'initial' && (
            <div>
              <div className="ey-accent-border pl-4 mb-6">
                <h2 className="ey-heading-lg text-card-foreground mb-2">
                  Configure Drug Discovery Pipeline
                </h2>
                <p className="ey-body text-muted-foreground">
                  Set up your molecular analysis parameters for AI-powered compound screening 
                  and similarity search.
                </p>
              </div>

              <form onSubmit={handleSubmitInitial} className="space-y-6">
                {/* SMILES Input - Full Width at Top */}
                <div className="w-full">
                  <FormInput
                    label="SMILES of Reference Molecule"
                    value={formData.referenceMoleculeSmiles}
                    onChange={(value) => setFormData({ ...formData, referenceMoleculeSmiles: value })}
                    placeholder="e.g., CCO, CC(=O)OC1=CC=CC=C1C(=O)O"
                    required
                    error={errors.referenceMoleculeSmiles}
                    compact
                  />
                </div>

                {/* Parameters Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormInput
                    label="RCSB PDB Code"
                    value={formData.rcsbPdbCode}
                    onChange={(value) => setFormData({ ...formData, rcsbPdbCode: value })}
                    placeholder="e.g., 1ABC"
                    required
                    error={errors.rcsbPdbCode}
                    compact
                  />

                  <FormInput
                    label="Similarity Threshold"
                    type="number"
                    value={formData.similarityThreshold}
                    onChange={(value) => setFormData({ ...formData, similarityThreshold: value })}
                    placeholder="0.7"
                    required
                    error={errors.similarityThreshold}
                    compact
                  />

                  <FormInput
                    label="Fingerprinting Resolution"
                    type="number"
                    value={formData.fingerprintingResolution}
                    onChange={(value) => setFormData({ ...formData, fingerprintingResolution: value })}
                    placeholder="1024"
                    required
                    error={errors.fingerprintingResolution}
                    compact
                  />
                </div>

                {/* Submit Button - Full Width */}
                <div className="w-full">
                  <Button
                    type="submit"
                    loading={isLoading}
                    className="ey-button-primary w-full px-6 py-3 rounded-md"
                  >
                    <FlaskConical className="w-4 h-4 mr-2" />
                    Start Analysis
                  </Button>
                </div>

                <div className="ey-analysis-grid rounded-lg p-4">
                  <h4 className="ey-heading-sm text-card-foreground mb-3">Pipeline Overview</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="flex items-start space-x-2">
                      <div className="ey-accent-dot mt-1.5 flex-shrink-0"></div>
                      <span className="ey-body-sm text-muted-foreground">Fetch and analyze protein structure from RCSB PDB</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="ey-accent-dot mt-1.5 flex-shrink-0"></div>
                      <span className="ey-body-sm text-muted-foreground">Generate molecular fingerprints at specified resolution</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="ey-accent-dot mt-1.5 flex-shrink-0"></div>
                      <span className="ey-body-sm text-muted-foreground">Screen compound libraries using reference molecule similarity</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="ey-accent-dot mt-1.5 flex-shrink-0"></div>
                      <span className="ey-body-sm text-muted-foreground">Apply AI-powered filtering and ranking algorithms</span>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          )}

          {currentStep === 'followup' && apiResponse && (
            <div className="space-y-6">
              <div className="ey-accent-border pl-4">
                <h2 className="ey-heading-lg text-card-foreground mb-2">
                  Optimization Required
                </h2>
                <p className="ey-body text-muted-foreground">
                  Initial analysis complete. Select one of the AI recommendations below to proceed with optimization.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ResultCard response={apiResponse} />

                <div className="space-y-4">
                  <form onSubmit={handleSubmitFollowUp} className="space-y-4">
                    <div className="space-y-2">
                      <label className="block ey-caption text-muted-foreground font-medium">
                        AI RECOMMENDATIONS
                        <span className="text-destructive ml-1">*</span>
                      </label>
                      <select
                        value={selectedRecommendation}
                        onChange={(e) => setSelectedRecommendation(e.target.value)}
                        required
                        className="w-full px-3 py-2 ey-input rounded-md transition-all duration-200 font-medium text-sm"
                      >
                        <option value="">Select an optimization recommendation...</option>
                        {apiResponse.data?.recommendations?.map((rec: string, index: number) => (
                          <option key={index} value={rec}>
                            {rec}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col space-y-2">
                      <Button
                        type="submit"
                        loading={isLoading}
                        disabled={!selectedRecommendation}
                        className="ey-button-primary w-full px-6 py-2 rounded-md"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        Optimize Results
                      </Button>
                      <div className="flex space-x-2">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleReset}
                          className="ey-button-outline flex-1 px-3 py-2 rounded-md text-sm"
                        >
                          Reset Pipeline
                        </Button>
                        <Button
                          type="button"
                          variant="secondary"
                          onClick={handleSkipOptimization}
                          className="ey-button-secondary flex-1 px-3 py-2 rounded-md text-sm"
                        >
                          Skip Optimization
                        </Button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {currentStep === 'completed' && finalResponse && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="flex items-center justify-center mb-4">
                  <div className="w-12 h-12 ey-status-success rounded-full flex items-center justify-center">
                    <FlaskConical className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <h2 className="ey-heading-lg text-card-foreground mb-2">
                  Drug Discovery Complete
                </h2>
                <p className="ey-body text-muted-foreground">
                  Your comprehensive molecular analysis and compound screening results are ready.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ResultCard response={finalResponse} />

                {finalResponse.data && (
                  <div className="ey-analysis-grid rounded-lg p-4">
                    <h4 className="ey-heading-sm text-card-foreground mb-4">Research Deliverables</h4>
                    <div className="space-y-4">
                      {finalResponse.data.nextSteps && (
                        <div>
                          <h5 className="ey-body font-semibold text-card-foreground mb-2">Next Steps</h5>
                          <ul className="space-y-2">
                            {finalResponse.data.nextSteps.map((step: string, index: number) => (
                              <li key={index} className="flex items-start space-x-2">
                                <div className="ey-accent-dot mt-1.5 flex-shrink-0" />
                                <span className="ey-body-sm text-muted-foreground">{step}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {finalResponse.data.deliverables && (
                        <div>
                          <h5 className="ey-body font-semibold text-card-foreground mb-2">Analysis Reports</h5>
                          <ul className="space-y-2">
                            {finalResponse.data.deliverables.map((deliverable: string, index: number) => (
                              <li key={index} className="flex items-start space-x-2">
                                <div className="ey-accent-dot mt-1.5 flex-shrink-0" />
                                <span className="ey-body-sm text-muted-foreground">{deliverable}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-center pt-4">
                <Button 
                  onClick={handleReset} 
                  variant="outline"
                  className="ey-button-outline px-6 py-2 rounded-md"
                >
                  <FlaskConical className="w-4 h-4 mr-2" />
                  New Analysis
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Chat Bot Components */}
      {currentStep === 'initial' && (
        <>
          <ChatBotToggle onClick={() => setIsChatOpen(true)} />
          <ChatBot 
            isOpen={isChatOpen} 
            onClose={() => setIsChatOpen(false)}
            onProteinSuggestion={handleProteinSuggestion}
          />
        </>
      )}
    </div>
  );
}

export default App;