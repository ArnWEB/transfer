import sql from 'mssql';

const config: sql.config = {
  server: process.env.DB_SERVER || '',
  database: process.env.DB_DATABASE || '',
  user: process.env.DB_USER || '',
  password: process.env.DB_PASSWORD || '',
  port: parseInt(process.env.DB_PORT || '1433'),
  options: {
    encrypt: true,
    trustServerCertificate: false,
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
};

let pool: sql.ConnectionPool | null = null;

export const getConnection = async (): Promise<sql.ConnectionPool> => {
  if (!pool) {
    pool = new sql.ConnectionPool(config);
    await pool.connect();
  }
  return pool;
};

export const initializeDatabase = async () => {
  try {
    const connection = await getConnection();
    
    // Create users table
    await connection.request().query(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' AND xtype='U')
      CREATE TABLE users (
        id INT IDENTITY(1,1) PRIMARY KEY,
        email NVARCHAR(255) UNIQUE NOT NULL,
        password NVARCHAR(255) NOT NULL,
        created_at DATETIME2 DEFAULT GETDATE(),
        updated_at DATETIME2 DEFAULT GETDATE()
      )
    `);

    // Create chat_feedback table
    await connection.request().query(`
      IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_feedback' AND xtype='U')
      CREATE TABLE chat_feedback (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NOT NULL,
        session_id NVARCHAR(255) NOT NULL,
        message_id NVARCHAR(255) NOT NULL,
        response_content NTEXT NOT NULL,
        feedback_type NVARCHAR(10) NULL,
        created_at DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Create index for better performance
    await connection.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name='IX_chat_feedback_user_session')
      CREATE INDEX IX_chat_feedback_user_session ON chat_feedback(user_id, session_id)
    `);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
};

export const closeConnection = async () => {
  if (pool) {
    await pool.close();
    pool = null;
  }
};