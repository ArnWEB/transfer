# CyberGuard AI - Cybersecurity Chat Assistant

A modern, secure chat application with Azure SQL database integration, user authentication, and AI response feedback tracking.

## Features

### 🔐 Authentication System
- User registration and login with email/password
- JWT token-based authentication
- Secure password hashing with bcrypt
- Session management with automatic token verification

### 💬 Chat Interface
- Modern ChatGPT-like interface
- Real-time messaging with thinking animations
- Responsive design for all screen sizes
- Cybersecurity-themed dark UI with neon accents

### 📊 Feedback System
- Like/dislike buttons for AI responses
- Feedback tracking in Azure SQL database
- Analytics for response quality monitoring
- User-specific feedback history

### 🗄️ Database Integration
- Azure SQL Server integration
- Automatic database schema initialization
- User management and chat feedback storage
- Connection pooling for optimal performance

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id INT IDENTITY(1,1) PRIMARY KEY,
  email NVARCHAR(255) UNIQUE NOT NULL,
  password NVARCHAR(255) NOT NULL,
  created_at DATETIME2 DEFAULT GETDATE(),
  updated_at DATETIME2 DEFAULT GETDATE()
)
```

### Chat Feedback Table
```sql
CREATE TABLE chat_feedback (
  id INT IDENTITY(1,1) PRIMARY KEY,
  user_id INT NOT NULL,
  session_id NVARCHAR(255) NOT NULL,
  message_id NVARCHAR(255) NOT NULL,
  response_content NTEXT NOT NULL,
  feedback_type NVARCHAR(10) NULL, -- 'like', 'dislike', or NULL
  created_at DATETIME2 DEFAULT GETDATE(),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)
```

## Environment Setup

Create a `.env` file with your Azure SQL configuration:

```env
# Azure SQL Database Configuration
DB_SERVER=your-azure-sql-server.database.windows.net
DB_DATABASE=your-database-name
DB_USER=your-username
DB_PASSWORD=your-password
DB_PORT=1433

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRES_IN=7d

# Application Configuration
NODE_ENV=development
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login

### Chat Feedback
- `POST /api/feedback/save` - Save user feedback for AI responses
- `GET /api/feedback/stats` - Get feedback statistics
- `GET /api/feedback/history` - Get user's feedback history

## Installation

1. Install dependencies:
```bash
npm install
```

2. Configure your Azure SQL database connection in `.env`

3. Start the development server:
```bash
npm run dev
```

## Security Features

- Password hashing with bcrypt (12 salt rounds)
- JWT token authentication with expiration
- SQL injection prevention with parameterized queries
- Input validation and sanitization
- Secure session management
- HTTPS-ready configuration

## Technologies Used

- **Frontend**: React, TypeScript, Tailwind CSS
- **Backend**: Node.js, Express (for API routes)
- **Database**: Azure SQL Server with mssql driver
- **Authentication**: JWT, bcrypt
- **UI Components**: Lucide React icons
- **Build Tool**: Vite

## Feedback Analytics

The system tracks three types of feedback:
- **Likes**: Positive user responses
- **Dislikes**: Negative user responses  
- **No Feedback**: Responses without user interaction

This data helps improve AI response quality and user experience.