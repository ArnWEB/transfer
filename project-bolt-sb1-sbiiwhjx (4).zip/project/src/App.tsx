import React from 'react';
import MolecularAnalysis from './components/MolecularAnalysis';

function App() {
  return (
    <div className="dark">
      <MolecularAnalysis />
    </div>
  );
}

export default App;